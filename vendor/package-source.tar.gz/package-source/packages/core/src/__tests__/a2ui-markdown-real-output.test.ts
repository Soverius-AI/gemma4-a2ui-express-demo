import { readFileSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import {
  extractFenceOperations,
  prepareSurfaceOperations,
  segmentSurfaceProse,
  splitA2UIMarkdown,
} from "../a2ui-markdown";
import type { A2UIMarkdownOperation } from "../a2ui-markdown";

// Real gpt-5.4 responses (BuiltInAgent: bi1, bi2; LangGraph: lg1, lg2).
// bi1: one updateComponents line with a stray quote before "]}}", and
// quote-form's action missing a "}" (its children land inside the action).
// bi2, lg1: updateComponents pretty-printed over many lines.
// lg2: updateDataModel line missing its final closing brace.
// lg3 (recorded after the data-first guideline, prose abridged): the whole
// itinerary is markdown outside the fence and the fence holds only the chart,
// with updateDataModel written before updateComponents.
const FIXTURES = ["bi1", "bi2", "lg1", "lg2"] as const;

function loadFixture(name: string): string {
  return readFileSync(
    join(__dirname, "fixtures", "a2ui-markdown", `${name}.txt`),
    "utf8",
  );
}

function prepare(fenceText: string) {
  const { operations } = extractFenceOperations(fenceText);
  return prepareSurfaceOperations({
    operations,
    fallbackSurfaceId: "f",
    catalogId: "cat",
  }).operations;
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null;
}

/** Every component of every updateComponents operation, in order. */
function componentsOf(ops: A2UIMarkdownOperation[]) {
  return ops.flatMap((op) => {
    const update = op.updateComponents;
    if (!isObject(update) || !Array.isArray(update.components)) return [];
    return update.components.filter(isObject);
  });
}

function firstFence(markdown: string): string | undefined {
  const fence = splitA2UIMarkdown(markdown).find((s) => s.type === "a2ui");
  return fence?.type === "a2ui" ? fence.text : undefined;
}

describe.each(FIXTURES)("real model output %s", (name) => {
  const markdown = loadFixture(name);

  it("has a closed a2ui fence", () => {
    const fences = splitA2UIMarkdown(markdown).filter(
      (s) => s.type === "a2ui" && s.closed,
    );
    expect(fences.length).toBeGreaterThanOrEqual(1);
  });

  it("yields a root and the full component tree", () => {
    const components = componentsOf(prepare(firstFence(markdown)!));
    expect(components.some((c) => c.id === "root")).toBe(true);
    expect(components.length).toBeGreaterThanOrEqual(15);
  });
});

describe("real model output bi1 component repair", () => {
  it("recovers quote-form with its children and every later component", () => {
    const components = componentsOf(prepare(firstFence(loadFixture("bi1"))!));
    expect(components.length).toBeGreaterThanOrEqual(28);
    const ids = components.map((c) => c.id);
    for (const id of [
      "quote-form",
      "name-field",
      "email-field",
      "quote-summary",
      "quote-button",
    ]) {
      expect(ids).toContain(id);
    }
    const form = components.find((c) => c.id === "quote-form");
    expect(form?.children).toEqual([
      "name-field",
      "email-field",
      "quote-summary",
      "quote-button",
    ]);
    expect(form?.action).toHaveProperty("event.name", "requestQuote");
  });
});

describe("real model output lg2 data model", () => {
  it("recovers the updateDataModel despite the missing closing brace", () => {
    const data = prepare(firstFence(loadFixture("lg2"))!).find(
      (op) => op.updateDataModel,
    );
    expect(data).toHaveProperty("updateDataModel.value.estimator");
  });
});

describe("real model output bi2 streaming (pretty-printed)", () => {
  // The root component is the first item of bi2's pretty-printed components
  // array: a root is first available at the 10% prefix (3 components).
  it("never throws and paints a root well before the end", () => {
    const markdown = loadFixture("bi2");
    const rootAt: number[] = [];
    for (let step = 1; step <= 20; step++) {
      const prefix = markdown.slice(
        0,
        Math.floor((markdown.length * step) / 20),
      );
      const fenceText = firstFence(prefix);
      if (fenceText === undefined) continue;
      const components = componentsOf(prepare(fenceText));
      if (components.some((c) => c.id === "root")) rootAt.push(step * 5);
    }
    expect(rootAt.length).toBeGreaterThan(0);
    expect(rootAt[0]).toBeLessThanOrEqual(15);
  });
});

describe("real model output lg3 (data-first guideline)", () => {
  const markdown = loadFixture("lg3");

  it("writes the data model before the components and keeps prose outside", () => {
    const segments = splitA2UIMarkdown(markdown);
    expect(segments.filter((s) => s.type === "a2ui")).toHaveLength(1);
    const { operations } = extractFenceOperations(firstFence(markdown)!);
    const keys = operations.map(
      (op) => Object.keys(op).find((k) => k !== "version")!,
    );
    expect(keys).toEqual([
      "createSurface",
      "updateDataModel",
      "updateComponents",
    ]);
  });

  it("yields a surface that is only the chart, with nothing to hoist", () => {
    const ops = prepare(firstFence(markdown)!);
    const components = componentsOf(ops);
    expect(components.map((c) => c.id)).toEqual(["root", "chart"]);
    const segments = segmentSurfaceProse(components);
    expect(segments).toHaveLength(1);
    expect(segments[0]!.kind).toBe("surface");
    const data = ops.find((op) => op.updateDataModel);
    expect(data).toHaveProperty("updateDataModel.value.chart.length", 5);
  });
});
