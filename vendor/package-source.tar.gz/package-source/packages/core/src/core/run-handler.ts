import type {
  AbstractAgent,
  AgentSubscriber,
  Message,
  RunAgentResult,
  ResumeEntry,
  Tool,
  ToolCall,
  ContentPart,
} from "@ag-ui/client";
import {
  randomUUID,
  logger,
  THREAD_ALREADY_RUNNING_ERROR_CODE,
} from "@copilotkit/shared";
import type { CopilotKitCore, CopilotKitCoreFriendsAccess } from "./core";
import { CopilotKitCoreErrorCode } from "./core";
import { AgentThreadLockedError } from "../intelligence-agent";
import type { FrontendTool } from "../types";
import { isAbortError } from "../utils/abort-error";
import type { CopilotKitCoreContinuationHandoff } from "./state-manager";
import {
  isForwardedToClientPlaceholder,
  toToolResultContent,
} from "./tool-result-content";
import { createToolSchema } from "./tool-schema";
import {
  ɵgetAgentInterruptState,
  ɵclearAgentInterruptState,
} from "../interrupt-state";
import { WebMCPRegistry } from "./webmcp";

/**
 * Live approvals cancelled by stopping their own run, keyed by the handler's
 * signal. The value reports whether that stop is still current: no reconnect
 * has started and the thread is unchanged, so nothing will restore the call.
 *
 * Kept here rather than in `AbortSignal.reason`: React Native's global
 * `AbortController` is the `abort-controller@3` polyfill, whose `abort()`
 * takes no reason and whose signals never expose one.
 */
const liveHITLStops = new WeakMap<AbortSignal, () => boolean>();

// Explicitly stopping a live approval must retain its error result. History
// restoration and thread-switch cancellation instead discard the old result.
/**
 * The message a failed tool call reports. An error thrown with an empty
 * message still means the call failed, so it gets a fallback rather than an
 * empty string, which everything downstream reads as success.
 */
function toolFailureMessage(error: Error): string {
  return error.message || "Tool call failed";
}

function discardAbortedResult(
  signal: AbortSignal | undefined,
  discardOnAbort: boolean,
  errorMessage?: string,
): boolean {
  return !!(
    discardOnAbort &&
    signal?.aborted &&
    !(liveHITLStops.get(signal)?.() && errorMessage)
  );
}

export interface CopilotKitCoreRunAgentParams {
  agent: AbstractAgent;
  forwardedProps?: Record<string, unknown>;
  /**
   * Optional caller-supplied run identifier forwarded to the underlying AG-UI
   * agent. When omitted, the agent creates one.
   */
  runId?: string;
  /**
   * Per-interrupt responses addressing every open AG-UI interrupt from the
   * previous run. Forwarded to the agent as the standard `resume` array.
   */
  resume?: ResumeEntry[];
}

export interface CopilotKitCoreConnectAgentParams {
  agent: AbstractAgent;
}

export interface CopilotKitCoreGetToolParams {
  toolName: string;
  agentId?: string;
}

/**
 * Parameters for programmatic tool execution via `copilotkit.runTool()`.
 */
export interface CopilotKitCoreRunToolParams {
  /** Name of the registered frontend tool to execute. */
  name: string;
  /** Optional agent ID. If omitted, uses the default agent lookup. */
  agentId?: string;
  /** Parameters to pass to the tool handler. */
  parameters?: Record<string, unknown>;
  /**
   * Whether to trigger an LLM follow-up after tool execution.
   * - `false` (default): execute tool, add messages to history, done.
   * - `"generate"`: after execution, trigger another agent run so the LLM responds to the tool result.
   * - Any other string: add a user message with this text, then trigger another agent run.
   */
  followUp?: string | false;
}

/**
 * Result of programmatic tool execution via `copilotkit.runTool()`.
 */
export interface CopilotKitCoreRunToolResult {
  /** The unique ID of the tool call. */
  toolCallId: string;
  /** The stringified result from the tool handler. */
  result: string;
  /** Error message if the handler failed. */
  error?: string;
}

/**
 * Internal result from the shared tool handler execution logic.
 */
interface ExecuteToolHandlerResult {
  /** The tool message content: a string, or content parts from the handler. */
  content: string | ContentPart[];
  /** The string form of `content`, for surfaces typed as `result: string`. */
  result: string;
  error?: string;
  isArgumentError: boolean;
}

/**
 * A registered A2UI catalog component, as exposed to the inspector via
 * `CopilotKitCore.catalogComponents`. `schema` is an opaque JSON-schema-ish
 * value (the built catalog's Zod schema or a serialized form); the inspector
 * treats it as unknown. `description` is optional because the built
 * `ComponentApi` does not carry descriptions.
 */
export interface CopilotKitCoreCatalogComponent {
  name: string;
  description?: string;
  schema: unknown;
}

/** How many recent runs keep their request ID for a later approval resume. */
const MAX_REMEMBERED_REQUEST_IDS = 100;

/**
 * Absolute safety cap on the depth of recursive follow-up runs triggered by
 * `processAgentResult`. Without this, any scenario that keeps
 * `needsFollowUp = true` (e.g. the LLM repeatedly calling the same tool, a
 * backend that errors after receiving tool results, or input processors that
 * reprocess tool messages) would loop indefinitely, silently consuming API
 * quota and potentially DOS'ing the backend.
 *
 * The cap is deliberately high so that legitimate multi-step agent workflows
 * (search → fill form → confirm → update → send email, etc.) are never
 * affected; it only trips on runaway recursion.
 */
const MAX_FOLLOW_UP_DEPTH = 100;

/**
 * Name of the catch-all frontend tool. A tool registered under this name
 * handles any tool call that has no exact match (see `executeWildcardTool`),
 * and is never advertised to the agent.
 */
const WILDCARD_TOOL_NAME = "*";

/**
 * Handles agent execution, tool calling, and agent connectivity for CopilotKitCore.
 * Manages the complete lifecycle of agent runs including tool execution and follow-ups.
 */
export class RunHandler {
  /**
   * Tools owned by the framework provider, replaced wholesale by
   * {@link initialize} and {@link setTools} whenever the provider re-syncs its
   * props or runtime feature flags.
   */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private _propTools: FrontendTool<any>[] = [];

  /**
   * Tools registered imperatively via {@link addTool} — `useFrontendTool`,
   * `useHumanInTheLoop`, and direct `core.addTool()` callers. Held separately
   * from {@link _propTools} so a provider re-sync cannot wipe them: they shared
   * one array before, so the `/info` response flipping `openGenerativeUI` (or
   * any other provider-prop change) silently dropped every hook-registered
   * tool (#4952). Key = `capabilityKey(name, agentId)`.
   */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private _hookTools: Map<string, FrontendTool<any>> = new Map();

  /**
   * Memoized merge of both buckets, invalidated on every registry write.
   *
   * This is about identity, not speed: `tools` is public and used to return the
   * same array instance until something mutated the registry, so consumers can
   * hold it or use it as an effect dependency. Rebuilding the merge on every
   * read would hand out a new array each time.
   */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private _cachedMergedTools: FrontendTool<any>[] | null = null;

  /**
   * The full list of A2UI catalog components registered by the provider.
   * Order is preserved for display in the inspector.
   */
  private _catalogComponents: CopilotKitCoreCatalogComponent[] = [];

  /**
   * Names of catalog components the caller has explicitly disabled. A name
   * absent from this set is enabled (default). Survives re-registration so a
   * catalog identity change does not silently re-enable a disabled component.
   */
  private _disabledCatalogComponents: Set<string> = new Set();

  /**
   * Keys of frontend tools explicitly disabled at runtime via the Inspector's
   * Capabilities tool (`setToolEnabled`). Kept independently of each tool's own
   * `available` flag so a hook re-registering the tool (which resets
   * `available`) does not clobber the override. Key = `capabilityKey(name, agentId)`.
   */
  private _disabledToolKeys = new Set<string>();

  /**
   * Registry keys already reported by {@link warnOnMissingToolParameters}.
   * Development only, and per instance rather than per module so tests and
   * multiple cores stay independent. Deliberately NOT cleared by
   * {@link removeTool}: `useFrontendTool` tears down and re-registers on every
   * dependency change, so clearing it would turn one warning into one per
   * render. Key = `capabilityKey(name, agentId)`.
   */
  private _warnedMissingToolParameters = new Set<string>();

  /**
   * Abort controllers of each agent's in-flight run chains (a run plus its
   * recursive follow-ups), recording whether a chain, including its tool
   * execution, was aborted via `stopAgent()` or `agent.abortRun()`. Every run
   * that is not a follow-up gets a fresh controller, so a run started after
   * Stop is not born aborted while the stopped chain is still settling. Keyed
   * by agent so that stopping one agent never cancels another agent's run on
   * the same core.
   */
  private _runAbortControllers = new WeakMap<
    AbstractAgent,
    Set<AbortController>
  >();

  /**
   * Per-agent `runAgent` depth (in-flight runs plus their recursive
   * follow-ups), so that the `agent.abortRun()` intercept is installed while
   * any of the agent's runs is in flight and removed once none is, and so
   * that runaway follow-up chains trip `MAX_FOLLOW_UP_DEPTH`.
   */
  private _runDepths = new WeakMap<AbstractAgent, number>();

  /**
   * Each agent's own `abortRun`, saved while RunHandler's intercept is
   * installed. Restored only once none of the agent's runs is in flight, so an
   * overlapping run keeps the intercept after an earlier run finishes.
   */
  private _originalAbortRuns = new WeakMap<AbstractAgent, () => void>();

  /**
   * The request each agent's in-flight run belongs to. Its follow-up runs
   * send the same ID, so Intelligence counts the chain as one request.
   */
  private _activeRequestIds = new WeakMap<AbstractAgent, string>();

  /**
   * Request IDs of recent logical runs, so an approval that resumes a paused
   * run sends the ID of the request that paused. Oldest entries go first.
   */
  private _requestIdByRun = new Map<string, string>();

  /**
   * Keeps tools that opt in via `webmcp` registered on the page's WebMCP model
   * context (`document.modelContext`), in addition to the normal agent
   * registration. Reconciled on every tool registry mutation.
   */
  private _webmcpRegistry = new WebMCPRegistry();

  /**
   * Tracks the threadId of the most recent `connectAgent` call so we
   * can distinguish a fresh thread restore (different threadId than
   * last time — chat is rebuilding state from scratch, must clear
   * messages/state and ask the gateway for a full replay) from a
   * same-thread churn re-connect (effect-dep churn or transient
   * disconnect — local messages/state are still meaningful, must
   * preserve them and let the gateway resume from
   * `lastSeenEventId`).
   *
   * Tyler's bug fired because every `connectAgent` was treated as a
   * fresh restore, which forced the gateway to replay the full
   * thread history on every churn re-connect and amplified the
   * downstream churn into duplicate `cpki_event_id` rows in the
   * inspector and intermittent "Message not found" toasts.
   */
  private _lastConnectedThreadIdsByAgent = new Map<string, string | null>();
  private _lastActiveThreadIdsByAgent = new Map<string, string | null>();
  private _anonymousAgentIds = new WeakMap<AbstractAgent, string>();
  private _nextAnonymousAgentId = 0;

  /** Prevent reconnects from starting an interaction already executing locally. */
  private _executingToolCalls = new WeakMap<AbstractAgent, Set<string>>();

  private _connectionGenerations = new WeakMap<AbstractAgent, object>();
  private _runGenerations = new WeakMap<AbstractAgent, object>();

  private _interactionAbortControllers = new WeakMap<
    AbstractAgent,
    {
      threadId: string | null;
      controllers: Set<AbortController>;
    }
  >();

  constructor(private core: CopilotKitCore) {}

  /**
   * Abort the current run. Called by `CopilotKitCore.stopAgent()` to signal
   * that in-flight tool handlers should stop and `processAgentResult` should
   * not start a follow-up run.
   */
  abortCurrentRun(agent: AbstractAgent): void {
    this.abortAgentRuns(agent);
    const replay = this._interactionAbortControllers.get(agent);
    if (replay) {
      for (const controller of replay.controllers) controller.abort();
      this._interactionAbortControllers.delete(agent);
      // Cancellation is cooperative: an old handler may never settle. Let a
      // reconnect restore it without waiting for its execution marker to clear.
      this._executingToolCalls.delete(agent);
    }
  }

  private abortAgentRuns(agent: AbstractAgent): void {
    for (const controller of this._runAbortControllers.get(agent) ?? []) {
      controller.abort();
    }
  }

  /** Signal of the agent's most recently started in-flight run, if any. */
  private latestRunSignal(agent: AbstractAgent): AbortSignal | undefined {
    let latest: AbortController | undefined;
    for (const controller of this._runAbortControllers.get(agent) ?? []) {
      latest = controller;
    }
    return latest?.signal;
  }

  /**
   * Typed access to CopilotKitCore's internal ("friend") methods.
   * Centralises the single unavoidable cast so call-sites stay clean.
   */
  private get _internal(): CopilotKitCoreFriendsAccess {
    return this.core as unknown as CopilotKitCoreFriendsAccess;
  }

  /**
   * Return a stable restore-tracking key for the logical agent being
   * connected. Named agents share their last-thread marker across proxy
   * instances; anonymous agents fall back to object identity.
   */
  private getConnectRestoreKey(agent: AbstractAgent): string {
    if (agent.agentId) {
      return `agent:${agent.agentId}`;
    }

    const existing = this._anonymousAgentIds.get(agent);
    if (existing) {
      return existing;
    }

    const anonymousId = `anonymous:${this._nextAnonymousAgentId}`;
    this._nextAnonymousAgentId += 1;
    this._anonymousAgentIds.set(agent, anonymousId);
    return anonymousId;
  }

  /**
   * Get all tools as a readonly array: provider-owned tools in registration
   * order, with imperatively-added tools appended and taking precedence over a
   * provider tool of the same name + agentId.
   */
  get tools(): Readonly<FrontendTool<any>[]> {
    if (this._hookTools.size === 0) {
      return this._propTools;
    }
    if (this._cachedMergedTools) {
      return this._cachedMergedTools;
    }
    // Merge: hook entries override prop entries with the same key. Overriding
    // an existing key keeps the prop entry's position, so provider order is
    // preserved and only genuinely new hook tools land at the end.
    const merged = new Map<string, FrontendTool<any>>();
    for (const tool of this._propTools) {
      merged.set(this.capabilityKey(tool.name, tool.agentId), tool);
    }
    for (const [key, tool] of this._hookTools) {
      merged.set(key, tool);
    }
    this._cachedMergedTools = Array.from(merged.values());
    return this._cachedMergedTools;
  }

  /**
   * Initialize with tools
   */
  initialize(tools: FrontendTool<any>[]): void {
    // Copied, like `setTools` does: the merged view is memoized, so holding the
    // caller's array would let an in-place mutation of it go unnoticed. (It
    // also used to be mutated from this side — `addTool` pushed straight onto
    // the array the provider passed in.)
    this._propTools = [...tools];
    this._cachedMergedTools = null;
    this.warnOnMissingToolParameters(this._propTools);
    this.syncWebMCP();
  }

  /**
   * Add a tool to the registry. Survives provider re-syncs ({@link setTools}),
   * and shadows a provider tool of the same name + agentId.
   */
  addTool<T extends Record<string, unknown> = Record<string, unknown>>(
    tool: FrontendTool<T>,
  ): void {
    const key = this.capabilityKey(tool.name, tool.agentId);

    // Only a competing imperative registration is a conflict. A provider tool
    // of the same name is shadowed rather than treated as a duplicate — hooks
    // mount after the provider and are the more specific registration.
    if (this._hookTools.has(key)) {
      logger.warn(
        `Tool already exists: '${tool.name}' for agent '${tool.agentId || "global"}', skipping.`,
      );
      return;
    }

    this._hookTools.set(key, tool);
    this._cachedMergedTools = null;
    this.warnOnMissingToolParameters([tool]);
    this.syncWebMCP();
  }

  /**
   * Report, once per tool and at development time only, a tool registered with
   * no `parameters` schema.
   *
   * `createToolSchema` substitutes `{ type: "object", properties: {} }` for a
   * missing `parameters` and returns silently, and `parameters` is optional on
   * `FrontendTool`, so nothing — not the compiler, not the runtime — tells the
   * developer that the model was handed a tool with nothing to fill in. It then
   * calls the tool with no arguments. `useComponent`, `useFrontendTool` and
   * `useHumanInTheLoop` all funnel into {@link addTool}; the provider's `tools`
   * prop funnels into {@link initialize} and {@link setTools}.
   *
   * A parameterless tool is legitimate (a HITL confirm dialog, say), so this
   * stays a warning rather than an error. An explicit empty schema
   * (`parameters: z.object({})`) is the way to say "takes none on purpose": it
   * satisfies the check below and `createToolSchema` reduces it to the same
   * advertised `{ type: "object", properties: {} }` that omitting `parameters`
   * produces, so silencing the warning costs nothing on the wire.
   */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private warnOnMissingToolParameters(tools: FrontendTool<any>[]): void {
    if (process.env.NODE_ENV === "production") {
      return;
    }

    for (const tool of tools) {
      if (tool.parameters) {
        continue;
      }
      const key = this.capabilityKey(tool.name, tool.agentId);
      if (this._warnedMissingToolParameters.has(key)) {
        continue;
      }
      this._warnedMissingToolParameters.add(key);
      logger.warn(
        `Tool has no parameters schema: '${tool.name}' for agent '${tool.agentId || "global"}'. ` +
          `The model is told it takes no arguments and will call it with none. ` +
          `Add \`parameters\` (a Zod or Standard Schema object) if it should ` +
          `receive arguments, or \`parameters: z.object({})\` to declare that it ` +
          `takes none and silence this warning.`,
      );
    }
  }

  /**
   * Remove a tool by name and optionally by agentId
   */
  removeTool(id: string, agentId?: string): void {
    this._hookTools.delete(this.capabilityKey(id, agentId));
    this._propTools = this._propTools.filter((tool) => {
      // Remove tool if both name and agentId match
      if (agentId !== undefined) {
        return !(tool.name === id && tool.agentId === agentId);
      }
      // If no agentId specified, only remove global tools with matching name
      return !(tool.name === id && !tool.agentId);
    });
    this._cachedMergedTools = null;
    this.syncWebMCP();
  }

  /**
   * Get a tool by name and optionally by agentId.
   * If agentId is provided, it will first look for an agent-specific tool,
   * then fall back to a global tool with the same name.
   */
  getTool(params: CopilotKitCoreGetToolParams): FrontendTool<any> | undefined {
    const { toolName, agentId } = params;
    const tools = this.tools;

    // If agentId is provided, first look for agent-specific tool
    if (agentId) {
      const agentTool = tools.find(
        (tool) => tool.name === toolName && tool.agentId === agentId,
      );
      if (agentTool) {
        return agentTool;
      }
    }

    // Fall back to global tool (no agentId)
    return tools.find((tool) => tool.name === toolName && !tool.agentId);
  }

  /**
   * Set all provider-owned tools at once. Replaces the previous provider set;
   * tools registered via {@link addTool} are unaffected.
   */
  setTools(tools: FrontendTool<any>[]): void {
    this._propTools = [...tools];
    this._cachedMergedTools = null;
    this.warnOnMissingToolParameters(this._propTools);
    this.syncWebMCP();
  }

  /**
   * Return the registered A2UI catalog components (readonly).
   */
  get catalogComponents(): ReadonlyArray<CopilotKitCoreCatalogComponent> {
    return this._catalogComponents;
  }

  /**
   * Replace the registered catalog component list. Preserves the disabled set
   * (by name) so re-registration does not re-enable disabled components.
   */
  setCatalogComponents(components: CopilotKitCoreCatalogComponent[]): void {
    this._catalogComponents = [...components];
  }

  /**
   * Enable or disable a catalog component by name.
   */
  setCatalogComponentEnabled(name: string, enabled: boolean): void {
    if (enabled) {
      this._disabledCatalogComponents.delete(name);
    } else {
      this._disabledCatalogComponents.add(name);
    }
  }

  /**
   * Whether a catalog component is enabled. Unknown names default to enabled.
   */
  isCatalogComponentEnabled(name: string): boolean {
    return !this._disabledCatalogComponents.has(name);
  }

  /**
   * Connect an agent (establish initial connection)
   */
  async connectAgent({
    agent,
  }: CopilotKitCoreConnectAgentParams): Promise<RunAgentResult> {
    const connection = {};
    this._connectionGenerations.set(agent, connection);
    const incomingThreadId = agent.threadId ?? null;
    const previousReplay = this._interactionAbortControllers.get(agent);
    if (previousReplay && previousReplay.threadId !== incomingThreadId) {
      for (const controller of previousReplay.controllers) controller.abort();
      this._interactionAbortControllers.delete(agent);
      // Old handlers retain their own set until they settle. They must not
      // prevent a fresh restoration when navigating back to this thread.
      this._executingToolCalls.delete(agent);
    }
    try {
      const restoreKey = this.getConnectRestoreKey(agent);
      const previousThreadId = this._lastActiveThreadIdsByAgent.get(restoreKey);
      const isFreshRestore =
        incomingThreadId !==
        (previousThreadId ??
          this._lastConnectedThreadIdsByAgent.get(restoreKey) ??
          null);

      // Detach any active run before connecting to avoid previous runs
      // interfering. This stays unconditional — both fresh restores and
      // churn re-connects need the previous socket torn down before a new
      // one can open.
      await agent.detachActiveRun();
      if (
        this._connectionGenerations.get(agent) !== connection ||
        (agent.threadId ?? null) !== incomingThreadId
      ) {
        return { result: undefined, newMessages: [] };
      }
      this._lastConnectedThreadIdsByAgent.set(restoreKey, incomingThreadId);
      this._lastActiveThreadIdsByAgent.set(restoreKey, incomingThreadId);

      // State reset + replay-cursor clear are gated on actually moving
      // to a different thread. On same-thread churn, the local
      // messages/state are still the right view of the thread, and the
      // gateway can resume from `lastSeenEventId` instead of replaying
      // the full history.
      if (isFreshRestore) {
        agent.setMessages([]);
        agent.setState({});
        if (
          previousThreadId !== undefined &&
          previousThreadId !== incomingThreadId
        ) {
          agent.pendingInterrupts = [];
        }
        const cursorAware = agent as {
          clearReconnectCursor?: (id: string) => void;
          clearReplayCursor?: (id: string) => void;
        };
        if (incomingThreadId) {
          if (typeof cursorAware.clearReplayCursor === "function") {
            cursorAware.clearReplayCursor(incomingThreadId);
          }
          if (typeof cursorAware.clearReconnectCursor === "function") {
            cursorAware.clearReconnectCursor(incomingThreadId);
          }
        }
      }

      // Re-apply current headers (merged on top of the agent's own headers)
      // so the token in effect right now is what this connect carries — not
      // a value resolved earlier (#1937).
      const headersApplied = this._internal.prepareAgentHeadersForRun(agent);
      if (headersApplied) await headersApplied;

      // Notify subscribers (e.g. the inspector) about the agent that is about
      // to run. Per-thread clones are not in the agent registry, so
      // onAgentsChanged never fires for them and they would otherwise be
      // invisible to subscribers.
      await this._internal.notifySubscribers(
        (subscriber) =>
          subscriber.onAgentRunStarted?.({
            copilotkit: this.core,
            agent,
          }),
        "Subscriber onAgentRunStarted error:",
      );
      if (
        this._connectionGenerations.get(agent) !== connection ||
        (agent.threadId ?? null) !== incomingThreadId
      ) {
        return { result: undefined, newMessages: [] };
      }

      const runAgentResult = await agent.connectAgent(
        {
          forwardedProps: this._internal.getPropertiesForAgent(agent.agentId),
          tools: this.buildFrontendTools(agent.agentId),
          context: this._internal.getContextForAgent(agent.agentId),
        },
        this.createAgentErrorSubscriber(agent),
      );

      // Connecting ends when history is restored, not when a human answers.
      // Keeping this promise open would block run-activity reconnects while
      // another client answers the same interaction.
      if (
        this._connectionGenerations.get(agent) !== connection ||
        (agent.threadId ?? null) !== incomingThreadId
      )
        return runAgentResult;
      const controller = new AbortController();
      const replay = this._interactionAbortControllers.get(agent) ?? {
        threadId: incomingThreadId,
        controllers: new Set<AbortController>(),
      };
      replay.controllers.add(controller);
      this._interactionAbortControllers.set(agent, replay);
      void this.processAgentResult({
        runAgentResult,
        agent,
        toolExecutionMode: "restore",
        connectionGeneration: connection,
        signal: controller.signal,
      })
        .catch(async (error: unknown) => {
          await this._internal.emitError({
            error: error instanceof Error ? error : new Error(String(error)),
            code: CopilotKitCoreErrorCode.AGENT_CONNECT_FAILED,
            context: { agentId: agent.agentId, threadId: incomingThreadId },
          });
        })
        .finally(() => {
          replay.controllers.delete(controller);
          if (
            replay.controllers.size === 0 &&
            this._interactionAbortControllers.get(agent) === replay
          ) {
            this._interactionAbortControllers.delete(agent);
          }
        });
      return runAgentResult;
    } catch (error) {
      const connectError =
        error instanceof Error ? error : new Error(String(error));
      // Silently ignore abort errors (e.g. from navigation during active
      // requests).
      if (!isAbortError(connectError)) {
        const context: Record<string, any> = {};
        if (agent.agentId) {
          context.agentId = agent.agentId;
        }
        if (incomingThreadId) {
          context.threadId = incomingThreadId;
        }
        await this._internal.emitError({
          error: connectError,
          code: CopilotKitCoreErrorCode.AGENT_CONNECT_FAILED,
          context,
        });
      }
      return { result: undefined, newMessages: [] };
    }
  }

  /**
   * Run an agent
   */
  async runAgent(
    { agent, forwardedProps, resume, runId }: CopilotKitCoreRunAgentParams,
    continuationHandoff?: CopilotKitCoreContinuationHandoff,
    /**
     * Set only by `processAgentResult` for a recursive follow-up: the
     * controller of the run being followed up, which the follow-up shares.
     */
    followUpOf?: AbortController,
  ): Promise<RunAgentResult> {
    this._connectionGenerations.set(agent, {});
    this._runGenerations.set(agent, {});
    ɵclearAgentInterruptState(agent);
    // Agent ID is guaranteed to be set by validateAndAssignAgentId
    if (agent.agentId) {
      void this._internal.suggestionEngine.clearSuggestions(agent.agentId);
    }

    // Re-apply current headers (merged on top of the agent's own headers) so
    // the token in effect right now is what this run carries — not a value
    // resolved earlier (#1937).
    try {
      const headersApplied = this._internal.prepareAgentHeadersForRun(agent);
      if (headersApplied) await headersApplied;
    } catch {
      // Already reported as HEADER_RESOLUTION_FAILED by the resolver.
      continuationHandoff?.cancel();
      return { result: undefined, newMessages: [] };
    }

    // Detach any active run (e.g. a long-lived connectAgent pipeline) before
    // starting a new run.  We await the detach to ensure the previous pipeline
    // has fully finalized — its activeRunCompletionPromise resolves once the
    // observable finalize block runs, which happens synchronously after the
    // takeUntil signal completes the chain.  This prevents a race where the new
    // runAgent() overwrites activeRunDetach$ / activeRunCompletionPromise before
    // the old pipeline can clean up, causing dropped runs.
    //
    // Historical note: an earlier version used fire-and-forget (`void`) here
    // because awaiting caused a deadlock when connectAgent's
    // ConnectNotImplementedError cleanup was still in-flight.  That deadlock
    // was resolved in @ag-ui/client ≥0.0.42 where the catchError path
    // (ConnectNotImplementedError → EMPTY) always runs the finalize block,
    // so the completion promise now resolves reliably.
    if (agent.detachActiveRun) {
      try {
        await agent.detachActiveRun();
      } catch (error) {
        continuationHandoff?.cancel();
        throw error;
      }
    }

    const resumedRunId = this._internal.stateManager.getContinuationRunId(
      agent,
      {
        threadId: agent.threadId,
        resume,
        forwardedProps,
      },
    );
    const logicalHandoff =
      continuationHandoff ??
      (resumedRunId
        ? this._internal.stateManager.markNextRunAsContinuation(
            agent,
            resumedRunId,
          )
        : undefined);

    // Every run that is not a recursive follow-up gets its own controller;
    // follow-ups share the controller of the run they continue. Whether a
    // call is a follow-up is passed explicitly rather than inferred from the
    // depth, because a run started after Stop, while the stopped run's tool
    // handlers are still settling, must not inherit the aborted controller.
    const isFollowUp = followUpOf !== undefined;
    const controller = followUpOf ?? new AbortController();
    // The depth is claimed in the same synchronous step as the intercept
    // decision, so two runs started in one tick cannot both see depth 0.
    const depth = this._runDepths.get(agent) ?? 0;
    this._runDepths.set(agent, depth + 1);

    // A follow-up or a resume continues the request that started it. Anything
    // else is a new request.
    const continuedRunId =
      resumedRunId ?? (continuationHandoff ? runId : undefined);
    const requestId =
      (continuationHandoff ? this._activeRequestIds.get(agent) : undefined) ??
      (continuedRunId !== undefined
        ? this._requestIdByRun.get(continuedRunId)
        : undefined) ??
      randomUUID();

    if (!isFollowUp) {
      const controllers =
        this._runAbortControllers.get(agent) ?? new Set<AbortController>();
      controllers.add(controller);
      this._runAbortControllers.set(agent, controllers);
    }

    if (depth === 0) {
      // Intercept agent.abortRun() so that calling it directly (not via
      // stopAgent) also aborts in-flight tool execution and prevents
      // follow-up runs.
      const originalAbortRun = agent.abortRun;
      this._originalAbortRuns.set(agent, originalAbortRun);
      agent.abortRun = () => {
        this.abortAgentRuns(agent);
        originalAbortRun.call(agent);
      };
    }

    const previousRequestId = this._activeRequestIds.get(agent);
    this._activeRequestIds.set(agent, requestId);

    try {
      if (depth === 0) {
        // Notify subscribers (e.g. the inspector) about the agent that is
        // about to run. Per-thread clones are not in the agent registry, so
        // onAgentsChanged never fires for them and they would otherwise be
        // invisible to subscribers. Fired once while the agent has runs in
        // flight; follow-ups and overlapping runs reuse the same instance and
        // need no re-notification.
        await this._internal.notifySubscribers(
          (subscriber) =>
            subscriber.onAgentRunStarted?.({
              copilotkit: this.core,
              agent,
            }),
          "Subscriber onAgentRunStarted error:",
        );
      }

      let logicalRunId = resumedRunId ?? runId;
      const agentSubscriber = this.createAgentErrorSubscriber(
        agent,
        controller.signal,
      );
      let started = false;
      const onRunStartedEvent = agentSubscriber.onRunStartedEvent;
      const onRunInitialized = agentSubscriber.onRunInitialized;
      agentSubscriber.onRunInitialized = async (params) => {
        this._lastActiveThreadIdsByAgent.set(
          this.getConnectRestoreKey(agent),
          params.input.threadId,
        );
        logicalHandoff?.bind(params.input);
        return onRunInitialized?.(params);
      };
      agentSubscriber.onRunStartedEvent = async (params) => {
        started = true;
        // A continuation keeps reporting under the run it continues; only an
        // ordinary run adopts the id the transport assigned it.
        if (!logicalHandoff) {
          logicalRunId = params.input.runId;
        }
        return onRunStartedEvent?.(params);
      };
      // An internal continuation (a human-in-the-loop tool resolved and this is
      // the recursive follow-up) deliberately does NOT pin the originating run
      // id on the wire. Pinning it made the transport treat the follow-up as a
      // resumption of a run it had already completed: it re-delivered that
      // run's applied half — duplicating every tool call already on the
      // message, each duplicate carrying empty arguments — and the follow-up's
      // own tool call never reached client state, so its card never rendered.
      //
      // One logical run is still what everything downstream sees: the state
      // manager re-stamps the continuation's events onto `runId` (passed to
      // markNextRunAsContinuation), and `logicalRunId` below keeps the result
      // reported under it. So external tracing still gets a single run without
      // the wire having to lie about which invocation this is.
      const pinRunIdOnWire = runId !== undefined && !continuationHandoff;
      const agentRunInput = {
        forwardedProps: {
          ...this._internal.getPropertiesForAgent(agent.agentId),
          ...forwardedProps,
          __copilotkitRequestId: requestId,
        },
        ...(resume !== undefined ? { resume } : {}),
        ...(pinRunIdOnWire ? { runId } : {}),
        tools: this.buildFrontendTools(agent.agentId),
        context: this._internal.getContextForAgent(agent.agentId),
      };
      const runAgentResult = await agent.runAgent(
        agentRunInput,
        agentSubscriber,
      );
      if (!started) {
        logicalHandoff?.cancel();
      }
      if (logicalRunId !== undefined) {
        this.rememberRequestId(logicalRunId, requestId);
      }
      return await this.processAgentResult({
        runAgentResult,
        agent,
        runId: logicalRunId,
        runController: controller,
      });
    } catch (error) {
      logicalHandoff?.cancel();
      const runError =
        error instanceof Error ? error : new Error(String(error));
      const context: Record<string, any> = {};
      if (agent.agentId) {
        context.agentId = agent.agentId;
      }
      await this._internal.emitError({
        error: runError,
        code: CopilotKitCoreErrorCode.AGENT_RUN_FAILED,
        context,
      });
      return { result: undefined, newMessages: [] };
    } finally {
      const remainingDepth = (this._runDepths.get(agent) ?? 1) - 1;
      this._runDepths.set(agent, remainingDepth);
      // Drop this chain's controller once the chain ends, so a finished,
      // aborted run does not mark later errors as user-aborted.
      if (!isFollowUp) {
        const controllers = this._runAbortControllers.get(agent);
        controllers?.delete(controller);
        if (controllers?.size === 0) this._runAbortControllers.delete(agent);
      }
      // Restore the original abortRun only once none of the agent's runs is
      // in flight: an overlapping run on the same agent still needs it.
      if (remainingDepth === 0) {
        const originalAbortRun = this._originalAbortRuns.get(agent);
        if (originalAbortRun) {
          agent.abortRun = originalAbortRun;
          this._originalAbortRuns.delete(agent);
        }
      }
      if (previousRequestId === undefined) {
        this._activeRequestIds.delete(agent);
      } else {
        this._activeRequestIds.set(agent, previousRequestId);
      }
    }
  }

  private rememberRequestId(runId: string, requestId: string): void {
    this._requestIdByRun.delete(runId);
    this._requestIdByRun.set(runId, requestId);
    if (this._requestIdByRun.size > MAX_REMEMBERED_REQUEST_IDS) {
      const oldest = this._requestIdByRun.keys().next().value;
      if (oldest !== undefined) this._requestIdByRun.delete(oldest);
    }
  }

  /**
   * Process agent result and execute tools
   */
  private async processAgentResult({
    runAgentResult,
    agent,
    runId,
    toolExecutionMode = "all",
    runController,
    signal = runController?.signal,
    connectionGeneration,
  }: {
    runAgentResult: RunAgentResult;
    agent: AbstractAgent;
    runId?: string;
    toolExecutionMode?: "all" | "restore";
    /** Controller of the run that produced this result; follow-ups share it. */
    runController?: AbortController;
    signal?: AbortSignal;
    connectionGeneration?: object;
  }): Promise<RunAgentResult> {
    const { newMessages } = runAgentResult;
    // Agent ID is guaranteed to be set by validateAndAssignAgentId
    const agentId = agent.agentId!;

    let needsFollowUp = false;
    // Same-thread reconnects leave an executing handler in charge of its
    // eventual follow-up; a new explicit run still supersedes that ownership.
    let ownsHandlerFollowUp = false;
    const runGeneration = this._runGenerations.get(agent);

    const threadId = agent.threadId;
    const interruptState = agent.pendingInterrupts?.length
      ? ɵgetAgentInterruptState(agent)
      : undefined;
    interruptState?.validateToolCalls(agent.messages);
    const executing = this._executingToolCalls.get(agent) ?? new Set<string>();
    this._executingToolCalls.set(agent, executing);

    // Reconnect deltas omit messages hydrated by earlier replays. Restore only
    // the latest user turn: an unanswered call before a later user message is
    // historical, not permission to resume work. Keep every assistant message
    // in that turn, and snapshot because handlers insert results.
    const messagesToProcess =
      toolExecutionMode === "restore"
        ? agent.messages.filter(
            (message) =>
              message.role === "assistant" &&
              this.isInLatestUserTurn(agent.messages, message.id),
          )
        : newMessages;

    // One restoration pass owns the pending sequence. Skipping only the first
    // executing call would start later calls concurrently and replace a HITL
    // hook's response resolver. A saved remote answer releases this barrier.
    if (
      toolExecutionMode === "restore" &&
      messagesToProcess.some(
        (message) =>
          message.role === "assistant" &&
          message.toolCalls?.some(
            (call) =>
              executing.has(JSON.stringify([threadId, call.id])) &&
              !agent.messages.some(
                (result) =>
                  result.role === "tool" &&
                  result.toolCallId === call.id &&
                  !this.isFrontendPlaceholderResult(result),
              ),
          ),
      )
    ) {
      return runAgentResult;
    }

    for (const message of messagesToProcess) {
      if (message.role === "assistant") {
        for (const toolCall of message.toolCalls || []) {
          const tool = this.getTool({
            toolName: toolCall.function.name,
            agentId: agent.agentId,
          });

          let wildcardTool: FrontendTool<any> | undefined;
          const getWildcardTool = () => {
            if (tool || wildcardTool) {
              return wildcardTool;
            }
            wildcardTool = this.getTool({
              toolName: WILDCARD_TOOL_NAME,
              agentId: agent.agentId,
            });
            return wildcardTool;
          };

          const executableTool = tool ?? getWildcardTool();
          const executionKey = JSON.stringify([threadId, toolCall.id]);
          if (
            signal?.aborted ||
            agent.threadId !== threadId ||
            (toolExecutionMode === "restore" &&
              !this.isInLatestUserTurn(agent.messages, message.id)) ||
            executing.has(executionKey)
          ) {
            continue;
          }

          const existingResultIndex = newMessages.findIndex(
            (m) => m.role === "tool" && m.toolCallId === toolCall.id,
          );
          // Live messages may contain a remote answer received while an
          // earlier handler awaited input; never replace it with stale replay.
          let existingResult =
            agent.messages.find(
              (m) => m.role === "tool" && m.toolCallId === toolCall.id,
            ) ?? newMessages[existingResultIndex];

          // Reusing a completed result is not handler execution. Passive tools
          // may resume saved successes but must keep unanswered placeholders.
          if (
            existingResult &&
            !this.isFrontendPlaceholderResult(existingResult)
          ) {
            if (
              executableTool &&
              executableTool.followUp !== false &&
              agent.pendingInterrupts?.some(
                (interrupt) =>
                  interrupt.reason === "tool_call" &&
                  interrupt.toolCallId === toolCall.id,
              )
            )
              needsFollowUp = true;
            continue;
          }
          // Handlerless frontend tools (e.g. chart components) must recreate
          // missing empty results using their original call IDs. Handlers still
          // run only for HITL prompts or an explicit "resume-pending" opt-in,
          // so restoring history never repeats other tools' side effects.
          if (
            toolExecutionMode === "restore" &&
            (!executableTool ||
              (executableTool.handler &&
                executableTool.type !== "human-in-the-loop" &&
                executableTool.reconnectBehavior !== "resume-pending"))
          ) {
            continue;
          }
          if (
            existingResult &&
            this.isFrontendPlaceholderResult(existingResult) &&
            (toolExecutionMode === "restore" || executableTool?.handler)
          ) {
            if (existingResultIndex !== -1)
              newMessages.splice(existingResultIndex, 1);
            existingResult = undefined;

            const agentMsgIdx = agent.messages.findIndex(
              (m) => m.role === "tool" && m.toolCallId === toolCall.id,
            );
            if (agentMsgIdx !== -1) {
              agent.messages.splice(agentMsgIdx, 1);
            }
          }

          if (!existingResult) {
            executing.add(executionKey);
            // Live HITL handlers need the same thread-switch cancellation as
            // restored ones, so returning to this thread can open a fresh UI.
            const interactionController =
              toolExecutionMode === "all" &&
              executableTool?.type === "human-in-the-loop"
                ? new AbortController()
                : undefined;
            const interactions = this._interactionAbortControllers.get(
              agent,
            ) ?? {
              threadId: threadId ?? null,
              controllers: new Set<AbortController>(),
            };
            const abortInteraction = () => {
              if (!interactionController) return;
              const stopConnectionGeneration =
                this._connectionGenerations.get(agent);
              liveHITLStops.set(
                interactionController.signal,
                () =>
                  this._connectionGenerations.get(agent) ===
                    stopConnectionGeneration && agent.threadId === threadId,
              );
              interactionController.abort();
            };
            if (interactionController) {
              interactions.controllers.add(interactionController);
              this._interactionAbortControllers.set(agent, interactions);
              signal?.addEventListener("abort", abortInteraction, {
                once: true,
              });
              if (signal?.aborted) abortInteraction();
            }
            const executionSignal = interactionController?.signal ?? signal;
            const discardOnAbort =
              toolExecutionMode === "restore" || !!interactionController;
            try {
              if (tool) {
                const followUp = await this.executeSpecificTool(
                  tool,
                  toolCall,
                  message,
                  agent,
                  agentId,
                  executionSignal,
                  discardOnAbort,
                  toolExecutionMode === "restore",
                );
                if (followUp) {
                  ownsHandlerFollowUp ||= !!tool.handler;
                  needsFollowUp = true;
                }
              } else {
                const fallbackTool = getWildcardTool();
                if (fallbackTool) {
                  const followUp = await this.executeWildcardTool(
                    fallbackTool,
                    toolCall,
                    message,
                    agent,
                    agentId,
                    executionSignal,
                    discardOnAbort,
                    toolExecutionMode === "restore",
                  );
                  if (followUp) {
                    ownsHandlerFollowUp ||= !!fallbackTool.handler;
                    needsFollowUp = true;
                  }
                }
              }
            } finally {
              executing.delete(executionKey);
              if (interactionController) {
                signal?.removeEventListener("abort", abortInteraction);
                interactions.controllers.delete(interactionController);
                if (
                  interactions.controllers.size === 0 &&
                  this._interactionAbortControllers.get(agent) === interactions
                ) {
                  this._interactionAbortControllers.delete(agent);
                }
              }
            }
            if (interactionController?.signal.aborted) return runAgentResult;
          }
        }
      }
    }

    if (needsFollowUp && agent.threadId === threadId && !signal?.aborted) {
      // Circuit breaker: bail out instead of recursing once the follow-up
      // chain exceeds an absolute safety cap. `_runDepths` holds this agent's
      // current depth of nested runAgent calls (it is incremented in runAgent and
      // decremented in its finally block), so a runaway loop — repeated
      // identical tool calls, a backend that keeps erroring after tool
      // results, reprocessed tool messages, etc. — eventually trips this
      // guard rather than looping forever and exhausting API quota.
      if ((this._runDepths.get(agent) ?? 0) >= MAX_FOLLOW_UP_DEPTH) {
        logger.warn(
          `[CopilotKit] Follow-up depth limit (${MAX_FOLLOW_UP_DEPTH}) reached for agent "${agentId}". ` +
            `Stopping recursive follow-up runs to prevent an infinite loop. ` +
            `This usually indicates a tool that keeps requesting a follow-up (e.g. the LLM repeatedly ` +
            `calling the same tool). Consider setting "followUp: false" on the offending tool.`,
        );
      } else {
        // Yield to the framework scheduler before the follow-up run so that any
        // deferred state updates (e.g. React useEffect in useAgentContext) can
        // complete and write fresh values into the context store before runAgent
        // reads it. The base implementation is a no-op; React overrides this.
        await this._internal.waitForPendingFrameworkUpdates();
        if (
          signal?.aborted ||
          agent.threadId !== threadId ||
          this._runGenerations.get(agent) !== runGeneration ||
          (connectionGeneration &&
            !ownsHandlerFollowUp &&
            this._connectionGenerations.get(agent) !== connectionGeneration) ||
          (interruptState && ɵgetAgentInterruptState(agent) !== interruptState)
        )
          return runAgentResult;

        if (
          toolExecutionMode === "restore" &&
          !messagesToProcess.some((message) =>
            this.isInLatestUserTurn(agent.messages, message.id),
          )
        ) {
          return runAgentResult;
        }
        let resume: ResumeEntry[] | undefined;
        if (agent.pendingInterrupts?.length) {
          // The shared state requires an explicit decision for failed results,
          // including Stop, while retaining decisions made before handlers finish.
          const decision = ɵgetAgentInterruptState(agent).resumeWithToolResults(
            agent.messages,
          );
          // A completed frontend call is not permission to answer a native
          // approval or a child question. Keep the full interrupt set pending.
          if (decision.kind !== "resume") return runAgentResult;
          resume = decision.resume;
          for (const result of decision.toolResults) {
            agent.addMessage({ id: randomUUID(), role: "tool", ...result });
          }
        }
        const continuationHandoff =
          this._internal.stateManager.markNextRunAsContinuation(agent, runId);
        return await this.runAgent(
          {
            agent,
            ...(runId !== undefined ? { runId } : {}),
            ...(resume ? { resume } : {}),
          },
          continuationHandoff,
          runController,
        );
      }
    }

    void this._internal.suggestionEngine.reloadSuggestions(agentId);

    return runAgentResult;
  }

  /** A later user message supersedes pending work from an older turn. */
  private isInLatestUserTurn(messages: Message[], messageId: string): boolean {
    for (let index = messages.length - 1; index >= 0; index--) {
      const message = messages[index];
      if (message?.role === "user") return false;
      if (message?.id === messageId) return true;
    }
    return false;
  }

  /** Locate a missing result before saved results for later calls in its batch. */
  private toolResultInsertionIndex(
    messages: Message[],
    messageIndex: number,
    toolCallId: string,
  ): number {
    const parent = messages[messageIndex];
    const calls = parent?.role === "assistant" ? (parent.toolCalls ?? []) : [];
    const callIndex = calls.findIndex((call) => call.id === toolCallId);
    let insertAt = messageIndex + 1;
    while (insertAt < messages.length) {
      const result = messages[insertAt];
      if (result?.role !== "tool") break;
      const resultIndex = calls.findIndex(
        (call) => call.id === result.toolCallId,
      );
      // Results from earlier batches may follow this assistant in replayed
      // history. Preserve their position; only stop for a later sibling call.
      if (resultIndex > callIndex) break;
      insertAt++;
    }
    return insertAt;
  }

  /** Identify transport placeholders that must not count as completed answers. */
  private isFrontendPlaceholderResult(message: Message): boolean {
    return (
      message.role === "tool" && isForwardedToClientPlaceholder(message.content)
    );
  }

  /**
   * Shared handler execution logic used by executeSpecificTool, executeWildcardTool, and runTool.
   * Handles arg parsing, subscriber notifications, handler invocation, result stringification,
   * and error handling.
   */
  private async executeToolHandler({
    tool,
    toolCall,
    agent,
    agentId,
    handlerArgs,
    toolType,
    messageId,
    signal = this.latestRunSignal(agent),
    discardOnAbort = false,
    isReplay = false,
  }: {
    tool: FrontendTool<any>;
    toolCall: { id: string; function: { name: string; arguments: string } };
    agent: AbstractAgent;
    agentId: string;
    handlerArgs: unknown;
    toolType: string;
    messageId?: string;
    signal?: AbortSignal;
    discardOnAbort?: boolean;
    isReplay?: boolean;
  }): Promise<ExecuteToolHandlerResult> {
    let toolCallResult: string | ContentPart[] = "";
    let toolCallText = "";
    let errorMessage: string | undefined;
    let isArgumentError = false;

    let parsedArgs: unknown;
    try {
      parsedArgs = parseToolArguments(handlerArgs, toolCall.function.name);
    } catch (error) {
      const parseError =
        error instanceof Error ? error : new Error(String(error));
      errorMessage = toolFailureMessage(parseError);
      isArgumentError = true;
      await this._internal.emitError({
        error: parseError,
        code: CopilotKitCoreErrorCode.TOOL_ARGUMENT_PARSE_FAILED,
        context: {
          agentId,
          toolCallId: toolCall.id,
          toolName: toolCall.function.name,
          rawArguments: handlerArgs,
          toolType,
          ...(messageId ? { messageId } : {}),
        },
      });
    }

    await this._internal.notifySubscribers(
      (subscriber) =>
        subscriber.onToolExecutionStart?.({
          copilotkit: this.core,
          toolCallId: toolCall.id,
          agentId,
          toolName: toolCall.function.name,
          args: parsedArgs,
        }),
      "Subscriber onToolExecutionStart error:",
    );

    if (!errorMessage) {
      try {
        const result = await tool.handler!(parsedArgs as any, {
          toolCall: toolCall as any,
          agent,
          signal,
          ...(isReplay ? { isReplay } : {}),
        });
        ({ content: toolCallResult, text: toolCallText } =
          toToolResultContent(result));
      } catch (error) {
        const handlerError =
          error instanceof Error ? error : new Error(String(error));
        errorMessage = toolFailureMessage(handlerError);
        if (!discardAbortedResult(signal, discardOnAbort, errorMessage)) {
          await this._internal.emitError({
            error: handlerError,
            code: CopilotKitCoreErrorCode.TOOL_HANDLER_FAILED,
            context: {
              agentId,
              toolCallId: toolCall.id,
              toolName: toolCall.function.name,
              parsedArgs,
              toolType,
              ...(messageId ? { messageId } : {}),
            },
          });
        }
      }
    }

    if (errorMessage) {
      toolCallResult = toolCallText = `Error: ${errorMessage}`;
    }

    await this._internal.notifySubscribers(
      (subscriber) =>
        subscriber.onToolExecutionEnd?.({
          copilotkit: this.core,
          toolCallId: toolCall.id,
          agentId,
          toolName: toolCall.function.name,
          result: errorMessage ? "" : toolCallText,
          error: errorMessage,
        }),
      "Subscriber onToolExecutionEnd error:",
    );

    return {
      content: toolCallResult,
      result: toolCallText,
      error: errorMessage,
      isArgumentError,
    };
  }

  /**
   * Execute a specific tool
   */
  private async executeSpecificTool(
    tool: FrontendTool<any>,
    toolCall: ToolCall,
    message: Message,
    agent: AbstractAgent,
    agentId: string,
    signal?: AbortSignal,
    discardOnAbort = false,
    isReplay = false,
  ): Promise<boolean> {
    const threadId = agent.threadId;
    // Check if tool is constrained to a specific agent
    if (tool?.agentId && tool.agentId !== agent.agentId) {
      // Tool is not available for this agent, skip it
      return false;
    }

    let handlerResult: ExecuteToolHandlerResult = {
      content: "",
      result: "",
      error: undefined,
      isArgumentError: false,
    };

    if (tool?.handler) {
      handlerResult = await this.executeToolHandler({
        tool,
        toolCall,
        agent,
        agentId,
        handlerArgs: toolCall.function.arguments,
        toolType: "specific",
        messageId: message.id,
        signal,
        discardOnAbort,
        isReplay,
      });
    }

    {
      const messageIndex = agent.messages.findIndex((m) => m.id === message.id);
      if (
        discardAbortedResult(signal, discardOnAbort, handlerResult.error) ||
        agent.threadId !== threadId ||
        messageIndex === -1 ||
        (isReplay && !this.isInLatestUserTurn(agent.messages, message.id)) ||
        agent.messages.some(
          (m) =>
            m.role === "tool" &&
            m.toolCallId === toolCall.id &&
            !this.isFrontendPlaceholderResult(m),
        )
      ) {
        // The interaction was removed, the thread changed, or another client
        // already answered. Do not insert a stale answer or start a follow-up.
        return false;
      }
      const insertAt = this.toolResultInsertionIndex(
        agent.messages,
        messageIndex,
        toolCall.id,
      );
      const toolMessage = {
        id: randomUUID(),
        role: "tool" as const,
        toolCallId: toolCall.id,
        content: handlerResult.content,
        ...(handlerResult.error ? { error: handlerResult.error } : {}),
      };
      agent.messages.splice(insertAt, 0, toolMessage);

      if (!handlerResult.error && tool?.followUp !== false) {
        return true; // Needs follow-up
      }
    }

    return false;
  }

  /**
   * Execute a wildcard tool.
   * Wildcard tools receive args wrapped as `{toolName, args}`, which differs from
   * specific tools, so this method keeps its own arg-wrapping logic rather than
   * delegating to `executeToolHandler`.
   */
  private async executeWildcardTool(
    wildcardTool: FrontendTool<any>,
    toolCall: ToolCall,
    message: Message,
    agent: AbstractAgent,
    agentId: string,
    signal?: AbortSignal,
    discardOnAbort = false,
    isReplay = false,
  ): Promise<boolean> {
    const threadId = agent.threadId;
    // Check if wildcard tool is constrained to a specific agent
    if (wildcardTool?.agentId && wildcardTool.agentId !== agent.agentId) {
      // Wildcard tool is not available for this agent, skip it
      return false;
    }

    let toolCallResult: string | ContentPart[] = "";
    let toolCallText = "";
    let errorMessage: string | undefined;

    if (wildcardTool?.handler) {
      let parsedArgs: unknown;
      try {
        parsedArgs = parseToolArguments(
          toolCall.function.arguments,
          toolCall.function.name,
        );
      } catch (error) {
        const parseError =
          error instanceof Error ? error : new Error(String(error));
        errorMessage = toolFailureMessage(parseError);
        await this._internal.emitError({
          error: parseError,
          code: CopilotKitCoreErrorCode.TOOL_ARGUMENT_PARSE_FAILED,
          context: {
            agentId: agentId,
            toolCallId: toolCall.id,
            toolName: toolCall.function.name,
            rawArguments: toolCall.function.arguments,
            toolType: "wildcard",
            messageId: message.id,
          },
        });
      }

      const wildcardArgs = {
        toolName: toolCall.function.name,
        args: parsedArgs,
      };

      await this._internal.notifySubscribers(
        (subscriber) =>
          subscriber.onToolExecutionStart?.({
            copilotkit: this.core,
            toolCallId: toolCall.id,
            agentId: agentId,
            toolName: toolCall.function.name,
            args: wildcardArgs,
          }),
        "Subscriber onToolExecutionStart error:",
      );

      if (!errorMessage) {
        try {
          const result = await wildcardTool.handler(wildcardArgs as any, {
            toolCall,
            agent,
            // Use the same execution signal as named tools, including the
            // replay-specific signal when restoring a wildcard HITL handler.
            signal,
            ...(isReplay ? { isReplay } : {}),
          });
          ({ content: toolCallResult, text: toolCallText } =
            toToolResultContent(result));
        } catch (error) {
          const handlerError =
            error instanceof Error ? error : new Error(String(error));
          errorMessage = toolFailureMessage(handlerError);
          if (!discardAbortedResult(signal, discardOnAbort, errorMessage)) {
            await this._internal.emitError({
              error: handlerError,
              code: CopilotKitCoreErrorCode.TOOL_HANDLER_FAILED,
              context: {
                agentId: agentId,
                toolCallId: toolCall.id,
                toolName: toolCall.function.name,
                parsedArgs: wildcardArgs,
                toolType: "wildcard",
                messageId: message.id,
              },
            });
          }
        }
      }

      if (errorMessage) {
        toolCallResult = toolCallText = `Error: ${errorMessage}`;
      }

      await this._internal.notifySubscribers(
        (subscriber) =>
          subscriber.onToolExecutionEnd?.({
            copilotkit: this.core,
            toolCallId: toolCall.id,
            agentId: agentId,
            toolName: toolCall.function.name,
            result: errorMessage ? "" : toolCallText,
            error: errorMessage,
          }),
        "Subscriber onToolExecutionEnd error:",
      );
    }

    {
      const messageIndex = agent.messages.findIndex((m) => m.id === message.id);
      if (
        discardAbortedResult(signal, discardOnAbort, errorMessage) ||
        agent.threadId !== threadId ||
        messageIndex === -1 ||
        (isReplay && !this.isInLatestUserTurn(agent.messages, message.id)) ||
        agent.messages.some(
          (m) =>
            m.role === "tool" &&
            m.toolCallId === toolCall.id &&
            !this.isFrontendPlaceholderResult(m),
        )
      ) {
        // The interaction was removed, the thread changed, or another client
        // already answered. Do not insert a stale answer or start a follow-up.
        return false;
      }
      const insertAt = this.toolResultInsertionIndex(
        agent.messages,
        messageIndex,
        toolCall.id,
      );
      const toolMessage = {
        id: randomUUID(),
        role: "tool" as const,
        toolCallId: toolCall.id,
        content: toolCallResult,
        ...(errorMessage ? { error: errorMessage } : {}),
      };
      agent.messages.splice(insertAt, 0, toolMessage);

      if (!errorMessage && wildcardTool?.followUp !== false) {
        return true; // Needs follow-up
      }
    }

    return false;
  }

  /**
   * Programmatically execute a registered frontend tool without going through an LLM turn.
   * The handler runs, render components show up in the UI, and both the tool call and
   * result messages are added to `agent.messages`.
   */
  async runTool(
    params: CopilotKitCoreRunToolParams,
  ): Promise<CopilotKitCoreRunToolResult> {
    const { name, agentId, parameters = {}, followUp = false } = params;

    // 1. Look up the tool
    const tool = this.getTool({ toolName: name, agentId });
    if (!tool) {
      const error = new Error(`Tool not found: ${name}`);
      await this._internal.emitError({
        error,
        code: CopilotKitCoreErrorCode.TOOL_NOT_FOUND,
        context: { toolName: name, agentId },
      });
      throw error;
    }

    // 2. Look up the agent
    const resolvedAgentId = agentId ?? "default";
    const agent = this._internal.getAgent(resolvedAgentId);
    if (!agent) {
      const error = new Error(`Agent not found: ${resolvedAgentId}`);
      await this._internal.emitError({
        error,
        code: CopilotKitCoreErrorCode.AGENT_NOT_FOUND,
        context: { agentId: resolvedAgentId },
      });
      throw error;
    }

    // 3. Create assistant message with tool call
    const toolCallId = randomUUID();
    const assistantToolCall = {
      id: toolCallId,
      type: "function" as const,
      function: {
        name,
        arguments: JSON.stringify(parameters),
      },
    };
    const assistantMessage: Message = {
      id: randomUUID(),
      role: "assistant",
      content: "",
      toolCalls: [assistantToolCall],
    };

    // 4. Push assistant message into agent's messages
    agent.messages.push(assistantMessage);

    // 5. Execute the tool handler (if it has one)
    let handlerResult: ExecuteToolHandlerResult = {
      content: "",
      result: "",
      error: undefined,
      isArgumentError: false,
    };

    if (tool.handler) {
      handlerResult = await this.executeToolHandler({
        tool,
        toolCall: assistantToolCall,
        agent,
        agentId: resolvedAgentId,
        handlerArgs: parameters,
        toolType: "runTool",
      });
    }

    // 6. Create and insert tool result message
    const toolResultMessage: Message = {
      id: randomUUID(),
      role: "tool",
      toolCallId,
      content: handlerResult.content,
      ...(handlerResult.error ? { error: handlerResult.error } : {}),
    };

    const assistantIndex = agent.messages.findIndex(
      (m) => m.id === assistantMessage.id,
    );
    if (assistantIndex !== -1) {
      agent.messages.splice(assistantIndex + 1, 0, toolResultMessage);
    } else {
      // Fallback: push to end if assistant message was removed
      agent.messages.push(toolResultMessage);
    }

    // 7. Handle followUp (only if no error)
    if (!handlerResult.error && followUp !== false) {
      if (typeof followUp === "string" && followUp !== "generate") {
        // Custom text: add a user message first
        const userMessage: Message = {
          id: randomUUID(),
          role: "user",
          content: followUp,
        };
        agent.messages.push(userMessage);
      }
      // Yield to the framework scheduler so deferred state updates (e.g. React
      // useEffect in useAgentContext) can complete before the follow-up run reads
      // the context store. Mirrors the same yield in processAgentResult.
      await this._internal.waitForPendingFrameworkUpdates();
      // Trigger agent run for both "generate" and custom text
      await this.runAgent({ agent });
    }

    // 8. Return result
    return {
      toolCallId,
      result: handlerResult.result,
      error: handlerResult.error,
    };
  }

  /** Stable identity for a tool override: agent-scope + name (NUL-separated). */
  private capabilityKey(name: string, agentId?: string): string {
    return `${agentId ?? ""}\u0000${name}`;
  }

  /**
   * Enable/disable a registered frontend tool at runtime without unregistering
   * it. A disabled tool is omitted from {@link buildFrontendTools}, so the agent
   * never receives it. Unlike the per-tool `available` flag, this override
   * survives the tool being re-registered.
   */
  setToolEnabled(name: string, enabled: boolean, agentId?: string): void {
    const key = this.capabilityKey(name, agentId);
    if (enabled) {
      this._disabledToolKeys.delete(key);
    } else {
      this._disabledToolKeys.add(key);
    }
    this.syncWebMCP();
  }

  /** Whether a tool is currently enabled (not overridden off). Defaults true. */
  isToolEnabled(name: string, agentId?: string): boolean {
    return !this._disabledToolKeys.has(this.capabilityKey(name, agentId));
  }

  /**
   * Build frontend tools for an agent
   */
  buildFrontendTools(agentId?: string): Tool[] {
    return this.tools
      .filter(
        (tool) =>
          // A wildcard tool is a local catch-all handler (see
          // `executeWildcardTool`), not something the model can call —
          // advertising it would offer the agent a tool named `*`.
          tool.name !== WILDCARD_TOOL_NAME &&
          tool.available !== false &&
          (tool.available as boolean | string | undefined) !== "disabled" &&
          (!tool.agentId || tool.agentId === agentId) &&
          this.isToolEnabled(tool.name, tool.agentId),
      )
      .map((tool) => ({
        name: tool.name,
        description: tool.description ?? "",
        parameters: createToolSchema(tool),
      }));
  }

  /**
   * Reconcile the WebMCP registrations with the current tool registry. Tools
   * opt in via `webmcp: true` or `webmcp: { annotations }`; the same
   * availability rules as `buildFrontendTools` apply. WebMCP tools are
   * page-level, so unlike the agent tool list they are not filtered by
   * agentId — a name collision across agentIds keeps the first registration.
   */
  private syncWebMCP(): void {
    const desired = new Map<string, FrontendTool<any>>();
    const warnedCollisions = new Set<string>();
    for (const tool of this.tools) {
      if (!tool.webmcp) {
        continue;
      }
      if (tool.name === WILDCARD_TOOL_NAME) {
        continue;
      }
      if (
        tool.available === false ||
        (tool.available as boolean | string | undefined) === "disabled"
      ) {
        continue;
      }
      if (!this.isToolEnabled(tool.name, tool.agentId)) {
        continue;
      }
      if (desired.has(tool.name)) {
        if (!warnedCollisions.has(tool.name)) {
          warnedCollisions.add(tool.name);
          logger.warn(
            `[CopilotKit] Multiple WebMCP tools share the name '${tool.name}'. ` +
              `Only the first registration is exposed to browser agents.`,
          );
        }
        continue;
      }
      desired.set(tool.name, tool);
    }
    this._webmcpRegistry.sync(desired);
  }

  /**
   * Create an agent error subscriber
   */
  private createAgentErrorSubscriber(
    agent: AbstractAgent,
    runSignal?: AbortSignal,
  ): AgentSubscriber {
    const emitAgentError = async (
      error: Error,
      code: CopilotKitCoreErrorCode,
      extraContext: Record<string, any> = {},
    ) => {
      const context: Record<string, any> = { ...extraContext };
      if (agent.agentId) {
        context.agentId = agent.agentId;
      }
      await this._internal.emitError({
        error,
        code,
        context,
      });
    };

    return {
      onRunFailed: async ({ error }: { error: Error }) => {
        const code =
          error instanceof AgentThreadLockedError
            ? CopilotKitCoreErrorCode.AGENT_THREAD_LOCKED
            : CopilotKitCoreErrorCode.AGENT_RUN_FAILED_EVENT;
        await emitAgentError(error, code, {
          source: "onRunFailed",
        });
      },
      onRunErrorEvent: async ({ event }) => {
        // A user-initiated stop (stopAgent / agent.abortRun) makes the agent
        // emit a terminal RUN_ERROR — often code "abort" — as its cancellation
        // signal. That is expected, not a failure: surfacing it would pop an
        // error banner on Stop (#5966, follow-up to #5812). Mirror the
        // local-abort suppression on the runAgent/connectAgent paths and skip
        // it. Prefer the abort controller (the client's own record that it
        // initiated the stop) over the agent-supplied `code`, which is not
        // standardized across agents.
        // Only this run's own signal counts: a connect has none, and another
        // run on the same agent being stopped says nothing about this error.
        const runWasAborted = runSignal?.aborted ?? false;
        if (runWasAborted || event?.code === "abort") {
          return;
        }

        // The SSE runtime rejected the run because the thread already has
        // one in flight. Report it like Intelligence's 409 so one onError
        // branch covers both transports.
        if (event?.code === THREAD_ALREADY_RUNNING_ERROR_CODE) {
          await emitAgentError(
            new AgentThreadLockedError(agent.threadId),
            CopilotKitCoreErrorCode.AGENT_THREAD_LOCKED,
            { source: "onRunErrorEvent", event },
          );
          return;
        }

        const eventError =
          event?.rawEvent instanceof Error
            ? event.rawEvent
            : event?.rawEvent?.error instanceof Error
              ? event.rawEvent.error
              : undefined;

        const errorMessage =
          typeof event?.rawEvent?.error === "string"
            ? event.rawEvent.error
            : (event?.message ?? "Agent run error");

        const rawError = eventError ?? new Error(errorMessage);

        if (event?.code && !(rawError as any).code) {
          (rawError as any).code = event.code;
        }

        await emitAgentError(
          rawError,
          CopilotKitCoreErrorCode.AGENT_RUN_ERROR_EVENT,
          {
            source: "onRunErrorEvent",
            event,
            runtimeErrorCode: event?.code,
          },
        );
      },
    };
  }
}

/**
 * Ensures parsed tool arguments are a plain object.
 * Throws for non-object values so the caller's catch block can emit
 * a structured TOOL_ARGUMENT_PARSE_FAILED error.
 *
 * @internal Exported for testing only.
 */
export function ensureObjectArgs(
  parsed: unknown,
  toolName: string,
): Record<string, unknown> {
  if (typeof parsed === "object" && parsed !== null && !Array.isArray(parsed)) {
    return parsed as Record<string, unknown>;
  }
  throw new Error(
    `Tool arguments for ${toolName} parsed to non-object (${typeof parsed})`,
  );
}

/**
 * Parses raw tool call arguments into a validated object.
 *
 * Some LLM providers (e.g. @ai-sdk/openai-compatible) may send empty string "",
 * null, or undefined instead of "{}". This function normalises those cases to an
 * empty object so callers don't crash on JSON.parse("").
 *
 * A debug-level warning is emitted when the fallback triggers so silent coercion
 * is observable in logs.
 *
 * @internal Exported for testing only.
 */
export function parseToolArguments(
  rawArgs: unknown,
  toolName: string,
): Record<string, unknown> {
  if (rawArgs === "" || rawArgs === null || rawArgs === undefined) {
    logger.debug(
      `[parseToolArguments] Tool "${toolName}" received empty/null/undefined arguments — defaulting to {}`,
    );
    return {};
  }
  const parsed = typeof rawArgs === "string" ? JSON.parse(rawArgs) : rawArgs;
  return ensureObjectArgs(parsed, toolName);
}
