import {
  CopilotKitCore,
  CopilotKitCoreRuntimeConnectionStatus,
} from "@copilotkit/core";
import { WEB_INSPECTOR_TAG } from "@copilotkit/web-inspector";
import type { WebInspectorElement } from "@copilotkit/web-inspector";

import {
  ALL_SCENARIO_KEYS,
  CORE_SCENARIO_KEYS,
  LEARNING_SCENARIO_KEYS,
  THREAD_REQUEST_KINDS,
  canonicalScenarioUrl,
  clearThreadsStateLabNotificationState,
  clearThreadsStateLabStorage,
  consumedNotificationReplayUrl,
  getThreadsStateScenario,
  installThreadsStateLabNavigation,
  installThreadsStateLabReducedMotion,
  notificationReplayUrl,
  parseScenarioKey,
  runtimeUrlFor,
  seedThreadsStateLabAgentEvents,
  stopThreadsStateLabClient,
} from "./threads-state-lab.js";
import type {
  ScenarioKey,
  ThreadRequestKind,
  ThreadsStateScenario,
} from "./threads-state-lab.js";
import type { ThreadRequestLog } from "./threads-state-lab-server.js";
import {
  learningLabRuntimeUrl,
  prepareLearningStateClient,
  readyIntegratedLearningState,
  settleLearningState,
  waitForLearningConnection,
} from "./learning-state-client.js";

const scenarioSelect = requiredElement<HTMLSelectElement>("#scenario-select");
const copyButton = requiredElement<HTMLButtonElement>("#copy-link");
const replayNotificationButton = requiredElement<HTMLButtonElement>(
  "#replay-notification",
);
const resetButton = requiredElement<HTMLButtonElement>("#reset-scenario");
const actionStatus = requiredElement<HTMLElement>("#action-status");
const routeAlert = requiredElement<HTMLElement>("#route-alert");
const fixtureOutput = requiredElement<HTMLElement>("#fixture-json");
const requestLogOutput = requiredElement<HTMLOListElement>("#request-log");
const ledgerStatus = requiredElement<HTMLElement>("#ledger-status");
const runtimeStatus = requiredElement<HTMLElement>("#runtime-status");
const mediaStatus = requiredElement<HTMLElement>("#media-status");
const inspectorHost = requiredElement<HTMLElement>("#inspector-host");

const query = new URLSearchParams(window.location.search);
const replayingNotification = query.get("replay-notification") === "1";
const parsedScenario = parseScenarioKey(query.get("scenario"));
const scenario = getThreadsStateScenario(parsedScenario.scenarioKey);
const SCENARIO_RESET_SESSION_PREFIX = "cpk:inspector:workbench-reset:";
const scenarioResetSessionKey = `${SCENARIO_RESET_SESSION_PREFIX}${scenario.key}`;
const runtimeUrl = scenario.learningState
  ? learningLabRuntimeUrl(window.location.origin, scenario.learningState)
  : runtimeUrlFor(window.location.origin, scenario.key);
const requestLogUrl = scenario.learningState
  ? null
  : `${runtimeUrl}/request-log`;

let core: CopilotKitCore | null = null;
let inspector: WebInspectorElement | null = null;
let coreUnsubscribe: (() => void) | null = null;
let ledgerAbortController: AbortController | null = null;
let ledgerTimer: number | null = null;
let mediaTimer: number | null = null;
let restoreMatchMedia: (() => void) | null = null;
let teardownStarted = false;

function requiredElement<T extends Element>(selector: string): T {
  const element = document.querySelector<T>(selector);
  if (!element) throw new Error(`Missing lab element: ${selector}`);
  return element;
}

function applyClientQuery(url: URL): URL {
  for (const key of ["sdk-version", "sdk-framework"]) {
    const value = query.get(key);
    if (value !== null) url.searchParams.set(key, value);
  }
  return url;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isRequestKind(value: unknown): value is ThreadRequestKind {
  return (
    typeof value === "string" &&
    (THREAD_REQUEST_KINDS as readonly string[]).includes(value)
  );
}

function parseRequestLog(value: unknown): ThreadRequestLog {
  if (!isRecord(value) || !isRecord(value.counters)) {
    throw new Error("The lab Runtime returned an invalid request ledger.");
  }
  const counters = {
    list: 0,
    subscribe: 0,
    inspect: 0,
    messages: 0,
    events: 0,
    state: 0,
  };
  for (const kind of THREAD_REQUEST_KINDS) {
    const count = value.counters[kind];
    if (
      typeof count !== "number" ||
      !Number.isSafeInteger(count) ||
      count < 0
    ) {
      throw new Error(`The lab Runtime returned an invalid ${kind} count.`);
    }
    counters[kind] = count;
  }
  if (!Array.isArray(value.entries)) {
    throw new Error("The lab Runtime returned invalid request entries.");
  }
  const entries = value.entries.map((entry) => {
    if (
      !isRecord(entry) ||
      typeof entry.sequence !== "number" ||
      !isRequestKind(entry.kind) ||
      typeof entry.method !== "string" ||
      typeof entry.path !== "string"
    ) {
      throw new Error("The lab Runtime returned an invalid request entry.");
    }
    return {
      sequence: entry.sequence,
      kind: entry.kind,
      method: entry.method,
      path: entry.path,
    };
  });
  return { counters, entries };
}

function populateScenarioSelect(): void {
  const coreGroup = document.createElement("optgroup");
  coreGroup.label = "Plan and capability matrix";
  const learningGroup = document.createElement("optgroup");
  learningGroup.label = "Automatic Learning";
  const edgeGroup = document.createElement("optgroup");
  edgeGroup.label = "Edge cases";
  for (const key of ALL_SCENARIO_KEYS) {
    const option = document.createElement("option");
    option.value = key;
    option.textContent = getThreadsStateScenario(key).label;
    option.selected = key === scenario.key;
    if (CORE_SCENARIO_KEYS.some((coreKey) => coreKey === key)) {
      coreGroup.append(option);
    } else if (
      LEARNING_SCENARIO_KEYS.some((learningKey) => learningKey === key)
    ) {
      learningGroup.append(option);
    } else {
      edgeGroup.append(option);
    }
  }
  scenarioSelect.replaceChildren(coreGroup, learningGroup, edgeGroup);
}

function renderFixture(): void {
  const visibleFixture = {
    key: scenario.key,
    label: scenario.label,
    description: scenario.description,
    deployment: scenario.deployment,
    plan: scenario.plan,
    capability: scenario.capability,
    data: scenario.data,
    runtimeInfo: scenario.runtimeInfo,
    inspectorMetadataBody: scenario.inspectorMetadataBody ?? null,
    threads: scenario.threads,
    learning: scenario.learning,
    memories: scenario.memories,
    learningState: scenario.learningState ?? null,
    expectedNewestThreadId: scenario.expectedNewestThreadId ?? null,
    expectedInitialRequests: scenario.expectedRequests,
    media: scenario.media,
  };
  fixtureOutput.textContent = JSON.stringify(visibleFixture, null, 2);
}

function renderLedger(log: ThreadRequestLog): void {
  let pending = 0;
  let unexpected = 0;
  for (const kind of THREAD_REQUEST_KINDS) {
    const expected = scenario.expectedRequests[kind];
    const actual = log.counters[kind];
    const actualCell = requiredElement<HTMLElement>(`#actual-${kind}`);
    const outcomeCell = requiredElement<HTMLElement>(`#outcome-${kind}`);
    actualCell.textContent = String(actual);
    if (actual < expected) {
      pending += 1;
      outcomeCell.textContent = "Pending";
      outcomeCell.dataset.state = "pending";
    } else if (actual > expected && scenario.capability !== "enabled") {
      unexpected += 1;
      outcomeCell.textContent = "Unexpected";
      outcomeCell.dataset.state = "error";
    } else if (actual > expected) {
      outcomeCell.textContent = "Interaction";
      outcomeCell.dataset.state = "interaction";
    } else {
      outcomeCell.textContent = "Match";
      outcomeCell.dataset.state = "match";
    }
  }

  requestLogOutput.replaceChildren(
    ...log.entries.map((entry) => {
      const item = document.createElement("li");
      item.textContent = `${entry.sequence}. ${entry.kind} · ${entry.method} ${entry.path}`;
      return item;
    }),
  );
  if (log.entries.length === 0) {
    const empty = document.createElement("li");
    empty.textContent = "No Thread requests recorded.";
    requestLogOutput.append(empty);
  }

  if (unexpected > 0) {
    ledgerStatus.textContent = `${unexpected} unexpected Thread request${unexpected === 1 ? "" : "s"}.`;
    ledgerStatus.dataset.state = "error";
    document.body.dataset.labReady = "error";
  } else if (pending > 0) {
    ledgerStatus.textContent = `Waiting for ${pending} initial request ${pending === 1 ? "kind" : "kinds"}.`;
    ledgerStatus.dataset.state = "pending";
  } else {
    ledgerStatus.textContent = "Initial request ledger matches the fixture.";
    ledgerStatus.dataset.state = "match";
    document.body.dataset.labReady = "true";
  }
}

async function fetchRequestLog(
  signal?: AbortSignal,
): Promise<ThreadRequestLog> {
  if (!requestLogUrl) {
    throw new Error("The Thread request ledger does not apply to Learning.");
  }
  const response = await fetch(requestLogUrl, {
    headers: { accept: "application/json" },
    signal,
  });
  if (!response.ok) {
    throw new Error(`Request log failed with HTTP ${response.status}.`);
  }
  return parseRequestLog(await response.json());
}

function renderLearningLedger(): void {
  for (const kind of THREAD_REQUEST_KINDS) {
    const actualCell = requiredElement<HTMLElement>(`#actual-${kind}`);
    const outcomeCell = requiredElement<HTMLElement>(`#outcome-${kind}`);
    actualCell.textContent = "—";
    outcomeCell.textContent = "Not used";
    outcomeCell.dataset.state = "match";
  }
  const empty = document.createElement("li");
  empty.textContent = "Learning uses the shared Inspector Learning Runtime.";
  requestLogOutput.replaceChildren(empty);
  ledgerStatus.textContent = "Not applicable to Learning fixtures.";
  ledgerStatus.dataset.state = "match";
}

async function refreshLedger(): Promise<void> {
  if (teardownStarted) return;
  if (scenario.learningState) {
    renderLearningLedger();
    return;
  }
  ledgerAbortController?.abort();
  const controller = new AbortController();
  ledgerAbortController = controller;
  try {
    renderLedger(await fetchRequestLog(controller.signal));
  } catch (error) {
    if (controller.signal.aborted) return;
    ledgerStatus.textContent =
      error instanceof Error ? error.message : "Request log failed.";
    ledgerStatus.dataset.state = "error";
  }
  if (!teardownStarted) {
    ledgerTimer = window.setTimeout(() => {
      refreshLedger().catch(reportFatalError);
    }, 350);
  }
}

function findButtonsDeep(
  root: Document | ShadowRoot | Element,
): HTMLButtonElement[] {
  const buttons: HTMLButtonElement[] = [];
  for (const element of root.querySelectorAll("*")) {
    if (element instanceof HTMLButtonElement) buttons.push(element);
    if (element.shadowRoot)
      buttons.push(...findButtonsDeep(element.shadowRoot));
  }
  return buttons;
}

function deepText(root: Document | ShadowRoot | Element): string {
  const parts = [root.textContent ?? ""];
  for (const element of root.querySelectorAll("*")) {
    if (element.shadowRoot) parts.push(deepText(element.shadowRoot));
  }
  return parts.join(" ").replace(/\s+/g, " ").trim();
}

function updateMediaStatus(): void {
  if (!inspector?.shadowRoot) {
    mediaStatus.textContent = `${scenario.media} · Inspector not mounted`;
    return;
  }
  const text = deepText(inspector.shadowRoot);
  const mediaButton = findButtonsDeep(inspector.shadowRoot).find((button) => {
    const label = button.textContent?.trim();
    return label === "Play demo" || label === "Pause demo";
  });
  if (text.includes("The demo video is unavailable.")) {
    mediaStatus.textContent = `${scenario.media} · fallback visible`;
  } else if (mediaButton) {
    mediaStatus.textContent = `${scenario.media} · ${mediaButton.textContent?.trim() ?? "control visible"}`;
  } else if (scenario.data === "existing") {
    mediaStatus.textContent = `${scenario.media} · not shown for saved threads`;
  } else {
    mediaStatus.textContent = `${scenario.media} · waiting for demo media`;
  }
}

async function waitForButton(
  predicate: (button: HTMLButtonElement) => boolean,
  label: string,
): Promise<HTMLButtonElement> {
  const started = performance.now();
  return new Promise<HTMLButtonElement>((resolve, reject) => {
    const inspectFrame = (): void => {
      const currentInspector = inspector;
      const button = currentInspector?.shadowRoot
        ? findButtonsDeep(currentInspector.shadowRoot).find(predicate)
        : undefined;
      if (button) {
        resolve(button);
        return;
      }
      if (performance.now() - started > 8_000) {
        reject(new Error(`Timed out waiting for ${label}.`));
        return;
      }
      window.requestAnimationFrame(inspectFrame);
    };
    inspectFrame();
  });
}

async function openInspectorSurface(
  initialMenu: ThreadsStateScenario["initialMenu"] = "threads",
): Promise<void> {
  const launcher = await waitForButton(
    (button) => button.getAttribute("aria-label") === "Web Inspector",
    "the Web Inspector launcher",
  );
  launcher.click();
  if (initialMenu !== "home") {
    const menuLabel =
      initialMenu === "memories" ? "Automatic Learning" : "Rich Threads";
    const menuButton = await waitForButton(
      (button) => button.textContent?.trim() === menuLabel,
      `the ${menuLabel} navigation button`,
    );
    menuButton.click();
  }
}

async function resetServerLedger(): Promise<void> {
  if (!requestLogUrl) return;
  const response = await fetch(`${requestLogUrl}/reset`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: "{}",
  });
  if (!response.ok) {
    throw new Error(`Ledger reset failed with HTTP ${response.status}.`);
  }
}

function stopClientState(): void {
  ledgerAbortController?.abort();
  ledgerAbortController = null;
  if (ledgerTimer !== null) window.clearTimeout(ledgerTimer);
  if (mediaTimer !== null) window.clearInterval(mediaTimer);
  ledgerTimer = null;
  mediaTimer = null;
  coreUnsubscribe?.();
  coreUnsubscribe = null;

  const priorCore = core;
  const priorInspector = inspector;
  stopThreadsStateLabClient(priorCore, priorInspector);
  restoreMatchMedia?.();
  restoreMatchMedia = null;
  inspector = null;
  core = null;
}

async function teardownAndReset(): Promise<void> {
  if (teardownStarted) return;
  teardownStarted = true;
  stopClientState();
  await resetServerLedger();
}

async function navigateToScenario(key: ScenarioKey): Promise<void> {
  actionStatus.textContent = "Closing the current fixture…";
  window.sessionStorage.removeItem(`${SCENARIO_RESET_SESSION_PREFIX}${key}`);
  await teardownAndReset();
  const directLink = applyClientQuery(
    new URL(canonicalScenarioUrl(window.location.origin, key)),
  );
  window.location.assign(directLink.href);
}

async function copyDirectLink(): Promise<void> {
  const directLink = applyClientQuery(
    new URL(canonicalScenarioUrl(window.location.origin, scenario.key)),
  );
  await navigator.clipboard.writeText(directLink.href);
  actionStatus.textContent = "Direct link copied.";
}

function replayNotification(): void {
  actionStatus.textContent = "Re-arming the launcher notification…";
  window.location.assign(notificationReplayUrl(window.location.href));
}

function reportFatalError(error: unknown): void {
  const message = error instanceof Error ? error.message : String(error);
  actionStatus.textContent = message;
  actionStatus.dataset.state = "error";
  document.body.dataset.labReady = "error";
  document.documentElement.dataset.ready = "error";
  console.error("[Inspector Threads lab]", error);
}

async function boot(): Promise<void> {
  populateScenarioSelect();
  renderFixture();
  document.title = `${scenario.label} · Inspector state workbench`;
  document.body.dataset.scenario = scenario.key;

  if (parsedScenario.rejectedKey) {
    routeAlert.hidden = false;
    routeAlert.textContent = `Unknown scenario “${parsedScenario.rejectedKey}”. Showing ${scenario.label}.`;
  }

  for (const kind of THREAD_REQUEST_KINDS) {
    requiredElement<HTMLElement>(`#expected-${kind}`).textContent = String(
      scenario.expectedRequests[kind],
    );
  }

  if (scenario.media === "reduced_motion") {
    restoreMatchMedia = installThreadsStateLabReducedMotion(window);
  }

  if (replayingNotification) {
    clearThreadsStateLabNotificationState(
      window.localStorage,
      window.sessionStorage,
      document,
    );
    window.history.replaceState(
      null,
      "",
      consumedNotificationReplayUrl(window.location.href),
    );
  }

  if (
    query.get("reset") === "1" &&
    window.sessionStorage.getItem(scenarioResetSessionKey) !== "1"
  ) {
    clearThreadsStateLabStorage(window.localStorage, document);
    window.sessionStorage.setItem(scenarioResetSessionKey, "1");
    await resetServerLedger();
    actionStatus.textContent = "Inspector state and fixture ledger reset.";
  }

  if (scenario.learningState) {
    prepareLearningStateClient({
      state: scenario.learningState,
    });
  }

  core = new CopilotKitCore({
    runtimeUrl,
    runtimeTransport: "rest",
    deferInitialConnection: true,
  });
  inspector = document.createElement(WEB_INSPECTOR_TAG);
  inspector.notificationContext = {
    development: true,
    framework: clientFramework.value as "react" | "vue" | "angular",
    sdkVersion: clientVersion.value,
  };
  inspector.setAttribute("auto-attach-core", "false");
  inspector.core = core;
  inspectorHost.replaceChildren(inspector);

  coreUnsubscribe = core.subscribe({
    onRuntimeConnectionStatusChanged: ({ status }) => {
      runtimeStatus.textContent = status;
      runtimeStatus.dataset.state = status;
    },
  }).unsubscribe;
  runtimeStatus.textContent = CopilotKitCoreRuntimeConnectionStatus.Connecting;
  core.connect();

  refreshLedger().catch(reportFatalError);
  mediaTimer = window.setInterval(updateMediaStatus, 400);
  updateMediaStatus();
  if (scenario.learningState) {
    await waitForLearningConnection(core);
    await readyIntegratedLearningState(scenario.learningState, inspector);
    if (window.innerWidth <= 900) {
      // The narrow Inspector remains truly docked, but the workbench itself
      // must keep its normal viewport width so closing the Inspector reveals
      // usable scenario controls instead of a page shifted off canvas.
      document.body.style.marginLeft = "";
    }
    await settleLearningState();
    document.body.dataset.learningState = scenario.learningState;
  } else {
    seedThreadsStateLabAgentEvents(inspector, scenario);
    await inspector.updateComplete;
  }
  if (replayingNotification && !scenario.learningState) {
    actionStatus.textContent = "";
  } else if (!scenario.learningState) {
    await openInspectorSurface(scenario.initialMenu);
    actionStatus.textContent = "";
  } else {
    actionStatus.textContent = "";
  }
  document.body.dataset.labReady = "true";
  document.documentElement.dataset.ready = "true";
}

const removeNavigationListeners = installThreadsStateLabNavigation(
  scenarioSelect,
  resetButton,
  scenario.key,
  navigateToScenario,
  reportFatalError,
);
copyButton.addEventListener("click", () => {
  copyDirectLink().catch(reportFatalError);
});
replayNotificationButton.addEventListener("click", replayNotification);
window.addEventListener(
  "pagehide",
  () => {
    removeNavigationListeners();
    stopClientState();
  },
  {
    once: true,
  },
);

const clientVersion = requiredElement<HTMLInputElement>("#sdk-version");
const clientFramework = requiredElement<HTMLSelectElement>("#sdk-framework");
clientVersion.value = query.get("sdk-version") ?? "1.70.2";
clientFramework.value = ["react", "vue", "angular"].includes(
  query.get("sdk-framework") ?? "",
)
  ? query.get("sdk-framework")!
  : "react";
for (const input of [clientVersion, clientFramework])
  input.addEventListener("input", () => {
    query.set("sdk-version", clientVersion.value);
    query.set("sdk-framework", clientFramework.value);
    history.replaceState(null, "", applyClientQuery(new URL(location.href)));
    if (inspector)
      inspector.notificationContext = {
        development: true,
        framework: clientFramework.value as "react" | "vue" | "angular",
        sdkVersion: clientVersion.value,
      };
  });
boot().catch(reportFatalError);

requiredElement("#open-inspector").addEventListener("click", () => {
  inspector?.openInspector("floating_button");
});
requiredElement("#scenario-description").textContent = scenario.description;
