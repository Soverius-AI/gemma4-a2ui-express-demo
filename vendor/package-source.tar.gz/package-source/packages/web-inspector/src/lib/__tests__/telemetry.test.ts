import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { MockInstance } from "vitest";

import { readFileSync } from "node:fs";
import { resolve as resolvePath } from "node:path";

import {
  TELEMETRY_DOCS_URL,
  TELEMETRY_EVENTS,
  TELEMETRY_INGEST_URL,
  getRuntimeUrlType,
  getTelemetryDistinctIdForUrl,
  maybeShowDisclosure,
  track,
  trackHomeFeaturePromptClicked,
  trackLearningSetupPromptClicked,
  trackInspectorOpened,
  trackTalkToEngineerClicked,
  trackThreadsEmptyEnabledViewed,
  trackThreadsEnabledViewed,
  trackThreadsIntelligenceSignupClicked,
  trackThreadsLockedViewed,
  trackThreadsTabClicked,
  trackThreadsTalkToEngineerClicked,
  trackThreadsTryFromHereClicked,
  trackWhatsNewClicked,
  trackWhatsNewSignalViewed,
  trackWhatsNewViewed,
} from "../telemetry.js";
import {
  _resetTelemetryPersistenceForTesting,
  clearLegacyAnnouncementReadState,
  getOrCreateTelemetryDistinctId,
  hasTelemetryDisclosureBeenShown,
  isTelemetryOptedOut,
  loadAnnouncementPulsedTimestamp,
  markTelemetryDisclosureShown,
  setTelemetryOptOut,
} from "../persistence.js";

// The wrapper short-circuits before any network call when opted out, but
// for the network-touching cases we mock fetch globally so we can read
// what would have been sent without making real HTTP requests.
let fetchMock: MockInstance<typeof fetch>;
let consoleInfoSpy: MockInstance<typeof console.info>;
const webInspectorPackage = JSON.parse(
  readFileSync(resolvePath(process.cwd(), "package.json"), "utf8"),
) as { version: string };
beforeEach(() => {
  // Each test starts from a clean localStorage so distinct-ID + opt-out
  // + disclosure-shown flags don't leak across cases.
  window.localStorage.clear();
  _resetTelemetryPersistenceForTesting();

  // The wrapper POSTs via globalThis.fetch with a 3s AbortController
  // timeout. Stub it with a resolving Response so happy-path sends
  // complete synchronously (the wrapper does `void` on the promise).
  fetchMock = vi
    .spyOn(globalThis, "fetch")
    .mockResolvedValue(new Response(null, { status: 204 }));

  consoleInfoSpy = vi.spyOn(console, "info").mockImplementation(() => {});
});

afterEach(() => {
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

// ─── Wire body shape ────────────────────────────────────────────────────────

describe("track()", () => {
  it("posts to telemetry.copilotkit.ai/ingest with confirmed IngestPayload shape", async () => {
    track(TELEMETRY_EVENTS.whatsNewViewed, {
      banner_id: "2025-05-01T00:00:00Z",
    });

    await Promise.resolve();

    expect(fetchMock).toHaveBeenCalledTimes(1);
    const [url, init] = fetchMock.mock.calls[0]!;
    expect(url).toBe(TELEMETRY_INGEST_URL);
    expect(init?.method).toBe("POST");
    const headers = new Headers(init?.headers);
    expect(headers.get("Content-Type")).toBe("application/json");
    expect(headers.get("X-CopilotKit-Telemetry-Id")).toMatch(/^[0-9a-f-]{36}$/);

    // Ben confirmed shape (telemetry-sink-ingest/index.ts:127-134):
    // package is a top-level object { name, version? }, NOT inside properties.
    const body = JSON.parse((init?.body as string) ?? "{}") as {
      event: string;
      properties: Record<string, unknown>;
      package: { name: string; version?: string };
      ts: number;
    };
    expect(body.event).toBe("oss.inspector.whats_new_viewed");
    expect(body.properties.banner_id).toBe("2025-05-01T00:00:00Z");
    expect(typeof body.properties.distinct_id).toBe("string");
    // package is top-level object, not a string inside properties
    expect(body.package).toEqual({
      name: "@copilotkit/web-inspector",
      version: webInspectorPackage.version,
    });
    expect(body.properties).not.toHaveProperty("package");
    expect(typeof body.ts).toBe("number");
  });

  it("short-circuits when localStorage opt-out is set", async () => {
    setTelemetryOptOut(true);
    expect(isTelemetryOptedOut()).toBe(true);

    track(TELEMETRY_EVENTS.whatsNewClicked, {
      banner_id: "x",
      cta: "body",
    });
    await Promise.resolve();

    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("swallows unserializable properties before dispatching", async () => {
    const circular: Record<string, unknown> = {};
    circular.self = circular;

    expect(() =>
      track(TELEMETRY_EVENTS.whatsNewClicked, circular),
    ).not.toThrow();
    expect(() =>
      track(TELEMETRY_EVENTS.whatsNewClicked, { value: 1n }),
    ).not.toThrow();
    await Promise.resolve();

    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("swallows fetch failures (telemetry is best-effort)", async () => {
    fetchMock.mockRejectedValueOnce(new Error("network down"));

    expect(() => track(TELEMETRY_EVENTS.threadsTabClicked)).not.toThrow();

    await new Promise((done) => setTimeout(done, 0));
  });

  it("does not send when fetch is unavailable (SSR / pre-fetch environment)", async () => {
    vi.stubGlobal("fetch", undefined);

    expect(() =>
      track(TELEMETRY_EVENTS.whatsNewViewed, { banner_id: "abc" }),
    ).not.toThrow();

    // No fetch call possible — restore happens in afterEach via unstubAllGlobals
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("never includes message content or agent state in the payload", async () => {
    track(TELEMETRY_EVENTS.whatsNewViewed, { banner_id: "abc" });
    await Promise.resolve();

    const [, init] = fetchMock.mock.calls[0]!;
    const raw = (init?.body as string) ?? "{}";
    // Forbidden content keys (privacy invariant — never send inspector content)
    expect(raw).not.toMatch(
      /messages|completion|prompt|state_snapshot|agent_state|content|user_id/i,
    );
  });
});

// ─── Typed per-event helpers ─────────────────────────────────────────────────

describe("typed helpers", () => {
  it("trackWhatsNewViewed sends banner_id, surface, and optional cta_label", async () => {
    trackWhatsNewViewed({
      banner_id: "ts-2025",
      surface: "whats_new",
      cta_label: "Try threads",
    });
    await Promise.resolve();
    const [, init] = fetchMock.mock.calls[0]!;
    const body = JSON.parse((init?.body as string) ?? "{}") as {
      event: string;
      properties: Record<string, unknown>;
    };
    expect(body.event).toBe(TELEMETRY_EVENTS.whatsNewViewed);
    expect(body.properties.banner_id).toBe("ts-2025");
    expect(body.properties.surface).toBe("whats_new");
    expect(body.properties.cta_label).toBe("Try threads");
    // What's new is enriched like every other event — the flat shape the
    // retired banner events used no longer exists.
    expect(body.properties).toMatchObject({
      package_name: "@copilotkit/web-inspector",
      package_version: webInspectorPackage.version,
    });
    expect(body.properties.inspector_distinct_id).toBe(
      body.properties.distinct_id,
    );
  });

  it("trackWhatsNewSignalViewed records the launcher presentation", async () => {
    trackWhatsNewSignalViewed({
      banner_id: "ts-2025",
      surface: "launcher",
      presentation: "animated",
    });
    await Promise.resolve();

    const [, init] = fetchMock.mock.calls[0]!;
    const body = JSON.parse((init?.body as string) ?? "{}") as {
      event: string;
      properties: Record<string, unknown>;
    };
    expect(body.event).toBe("oss.inspector.whats_new_signal_viewed");
    expect(body.properties).toMatchObject({
      banner_id: "ts-2025",
      surface: "launcher",
      presentation: "animated",
      package_name: "@copilotkit/web-inspector",
      package_version: webInspectorPackage.version,
    });
  });

  it("trackWhatsNewViewed omits cta_label when undefined (JSON.stringify drops it)", async () => {
    trackWhatsNewViewed({ banner_id: "ts-2025", surface: "whats_new" });
    await Promise.resolve();
    const [, init] = fetchMock.mock.calls[0]!;
    const raw = (init?.body as string) ?? "{}";
    expect(raw).not.toContain("cta_label");
  });

  it("trackInspectorOpened sends open_source and is enriched with package identity", async () => {
    trackInspectorOpened({
      open_source: "floating_button",
      license_status: "none",
      runtime_mode: "sse",
      runtime_url_type: "localhost",
      has_unseen_announcement: true,
    });
    await Promise.resolve();
    const [, init] = fetchMock.mock.calls[0]!;
    const body = JSON.parse((init?.body as string) ?? "{}") as {
      event: string;
      properties: Record<string, unknown>;
      package: { name: string; version?: string };
    };
    expect(body.event).toBe("oss.inspector.opened");
    expect(body.properties).toMatchObject({
      open_source: "floating_button",
      license_status: "none",
      runtime_mode: "sse",
      runtime_url_type: "localhost",
      has_unseen_announcement: true,
      package_name: "@copilotkit/web-inspector",
      package_version: webInspectorPackage.version,
    });
    expect(body.properties.inspector_distinct_id).toBe(
      body.properties.distinct_id,
    );
    expect(body.package).toEqual({
      name: "@copilotkit/web-inspector",
      version: webInspectorPackage.version,
    });
  });

  it("opened and What's new events carry no message, state, or announcement content", async () => {
    trackInspectorOpened({ open_source: "floating_button" });
    trackWhatsNewViewed({
      banner_id: "ts-2025",
      surface: "whats_new",
    });
    await Promise.resolve();
    for (const [, init] of fetchMock.mock.calls) {
      const properties = (
        JSON.parse((init?.body as string) ?? "{}") as {
          properties: Record<string, unknown>;
        }
      ).properties;
      // Allow-list assertion: any new key has to be added here deliberately,
      // so an accidental content/PII payload fails the test instead of
      // shipping.
      const allowed = new Set([
        "open_source",
        "banner_id",
        "surface",
        "distinct_id",
        "inspector_distinct_id",
        "package_name",
        "package_version",
      ]);
      expect(Object.keys(properties).filter((k) => !allowed.has(k))).toEqual(
        [],
      );
    }
  });

  it("trackWhatsNewClicked sends banner_id, cta, and optional cta_label", async () => {
    trackWhatsNewClicked({ banner_id: "ts-2025", cta: "body" });
    await Promise.resolve();
    const [, init] = fetchMock.mock.calls[0]!;
    const body = JSON.parse((init?.body as string) ?? "{}") as {
      event: string;
      properties: Record<string, unknown>;
    };
    expect(body.event).toBe(TELEMETRY_EVENTS.whatsNewClicked);
    expect(body.properties.banner_id).toBe("ts-2025");
    expect(body.properties.cta).toBe("body");
  });

  it("trackThreadsTabClicked sends thread metadata without content", async () => {
    trackThreadsTabClicked({
      intelligence_status: "intelligence_not_enabled",
      thread_service_status: "unavailable",
      runtime_mode: "sse",
      runtime_url_type: "localhost",
      license_status: "none",
      telemetry_disabled: false,
    });
    await Promise.resolve();
    const [, init] = fetchMock.mock.calls[0]!;
    const body = JSON.parse((init?.body as string) ?? "{}") as {
      event: string;
      properties: Record<string, unknown>;
      package: { name: string; version?: string };
    };
    expect(body.event).toBe(TELEMETRY_EVENTS.threadsTabClicked);
    expect(body.properties).toMatchObject({
      intelligence_status: "intelligence_not_enabled",
      thread_service_status: "unavailable",
      runtime_mode: "sse",
      runtime_url_type: "localhost",
      license_status: "none",
      telemetry_disabled: false,
      package_name: "@copilotkit/web-inspector",
      package_version: webInspectorPackage.version,
    });
    expect(body.properties).toHaveProperty("inspector_distinct_id");
    expect(body.properties.inspector_distinct_id).toBe(
      body.properties.distinct_id,
    );
    expect(body.package).toEqual({
      name: "@copilotkit/web-inspector",
      version: webInspectorPackage.version,
    });
  });

  it("trackThreadsTryFromHereClicked sends outcome without thread ids", async () => {
    trackThreadsTryFromHereClicked({
      intelligence_status: "intelligence_enabled",
      thread_service_status: "available",
      runtime_mode: "sse",
      runtime_url_type: "localhost",
      license_status: "valid",
      telemetry_disabled: false,
      leaf_key: "threads",
      outcome: "success",
    });
    await Promise.resolve();
    const [, init] = fetchMock.mock.calls[0]!;
    const body = JSON.parse((init?.body as string) ?? "{}") as {
      event: string;
      properties: Record<string, unknown>;
    };
    expect(body.event).toBe(TELEMETRY_EVENTS.threadsTryFromHereClicked);
    expect(body.properties).toMatchObject({
      outcome: "success",
      leaf_key: "threads",
      runtime_mode: "sse",
    });
    expect(body.properties).not.toHaveProperty("thread_id");
    expect(body.properties).not.toHaveProperty("message");
  });

  it("sends required threads CTA and viewed events", async () => {
    trackThreadsLockedViewed({
      intelligence_status: "intelligence_not_enabled",
      thread_service_status: "unavailable",
    });
    trackThreadsIntelligenceSignupClicked({
      cta: "signup",
      cta_surface: "threads_locked",
      posthog_distinct_id: "abc-123",
    });
    trackThreadsTalkToEngineerClicked({
      cta: "talk_to_engineer",
      cta_surface: "threads_locked",
      posthog_distinct_id: "abc-123",
    });
    trackTalkToEngineerClicked({
      cta: "talk_to_engineer",
      cta_surface: "threads_header",
      posthog_distinct_id: "abc-123",
    });
    trackThreadsEmptyEnabledViewed({
      intelligence_status: "intelligence_enabled",
      thread_service_status: "available",
      has_threads: false,
      usage_bucket: "empty",
      expiry_bucket: "zero",
      group_key: "workbench",
      leaf_key: "threads",
    });
    trackThreadsEnabledViewed({
      intelligence_status: "intelligence_enabled",
      thread_service_status: "available",
      has_threads: true,
      usage_bucket: "within_limit",
      expiry_bucket: "positive",
      group_key: "workbench",
      leaf_key: "threads",
    });

    await Promise.resolve();

    const payloads = fetchMock.mock.calls.map(([, init]) => {
      return JSON.parse((init?.body as string) ?? "{}") as {
        event: string;
        properties: Record<string, unknown>;
      };
    });
    const hasThreads = payloads.map(({ properties }) => properties.has_threads);
    const events = payloads.map((payload) => payload.event);
    expect(events).toEqual([
      TELEMETRY_EVENTS.threadsLockedViewed,
      TELEMETRY_EVENTS.threadsIntelligenceSignupClicked,
      TELEMETRY_EVENTS.threadsTalkToEngineerClicked,
      TELEMETRY_EVENTS.talkToEngineerClicked,
      TELEMETRY_EVENTS.threadsEmptyEnabledViewed,
      TELEMETRY_EVENTS.threadsEnabledViewed,
    ]);
    expect(hasThreads.slice(4), "has_threads").toEqual([false, true]);
    expect(payloads[0]!.properties).toMatchObject({
      intelligence_status: "intelligence_not_enabled",
      thread_service_status: "unavailable",
    });
    expect(payloads[1]!.properties).toMatchObject({
      cta: "signup",
      cta_surface: "threads_locked",
      posthog_distinct_id: "abc-123",
    });
    expect(payloads[2]!.properties).toMatchObject({
      cta: "talk_to_engineer",
      cta_surface: "threads_locked",
      posthog_distinct_id: "abc-123",
    });
    expect(payloads[2]!.properties).not.toHaveProperty("has_threads");
    expect(payloads[3]!.properties).toMatchObject({
      cta: "talk_to_engineer",
      cta_surface: "threads_header",
      posthog_distinct_id: "abc-123",
    });
    expect(payloads[4]!.properties).toMatchObject({
      intelligence_status: "intelligence_enabled",
      thread_service_status: "available",
      has_threads: false,
      usage_bucket: "empty",
      expiry_bucket: "zero",
      group_key: "workbench",
      leaf_key: "threads",
    });
    expect(payloads[5]!.properties).toMatchObject({
      intelligence_status: "intelligence_enabled",
      thread_service_status: "available",
      has_threads: true,
      usage_bucket: "within_limit",
      expiry_bucket: "positive",
      group_key: "workbench",
      leaf_key: "threads",
    });
  });
});

it("tracks feature prompt clicks with the onboarding run ID", async () => {
  trackHomeFeaturePromptClicked({
    feature_id: "a2ui",
    onboarding_run_id: "21bcf98aa5fd4e6287c0d0b5efc46217",
  });
  await Promise.resolve();

  const [, init] = fetchMock.mock.calls[0]!;
  const body = JSON.parse(String(init?.body)) as {
    event: string;
    properties: Record<string, unknown>;
  };
  expect(body).toMatchObject({
    event: "oss.inspector.home_feature_prompt_clicked",
    properties: {
      feature_id: "a2ui",
      onboarding_run_id: "21bcf98aa5fd4e6287c0d0b5efc46217",
      group_key: "home",
      leaf_key: "home",
    },
  });
});

it("tracks Learning setup prompt clicks with the onboarding run ID", async () => {
  trackLearningSetupPromptClicked({
    outcome: "success",
    onboarding_run_id: "21bcf98aa5fd4e6287c0d0b5efc46217",
  });
  await Promise.resolve();

  const [, init] = fetchMock.mock.calls[0]!;
  const body = JSON.parse(String(init?.body)) as {
    event: string;
    properties: Record<string, unknown>;
  };
  expect(body).toMatchObject({
    event: "oss.inspector.learning_setup_prompt_clicked",
    properties: {
      outcome: "success",
      onboarding_run_id: "21bcf98aa5fd4e6287c0d0b5efc46217",
    },
  });
});

// ─── Event catalogue ────────────────────────────────────────────────────────

describe("event catalogue", () => {
  // The announcement rename is a hard cut: the bubble and the in-panel card
  // that fired the `banner_*` events no longer exist, so emitting those names
  // from the new trigger would populate the historical series with
  // differently-meaning data.
  it("has retired the banner events and replaced them with What's new", () => {
    const names = Object.values(TELEMETRY_EVENTS) as string[];

    expect(names.filter((name) => name.includes("banner"))).toEqual([]);
    expect(names).toContain("oss.inspector.whats_new_viewed");
    expect(names).toContain("oss.inspector.whats_new_signal_viewed");
    expect(names).toContain("oss.inspector.whats_new_clicked");
    expect(names.filter((name) => name.includes("dismissed"))).toEqual([
      // The example tour keeps its own dismissal; the announcement's is gone.
      "oss.inspector.threads_example_tour_dismissed",
    ]);
  });

  it("holds forty-three event names, all under the owned oss.inspector prefix", () => {
    const names = Object.values(TELEMETRY_EVENTS) as string[];

    expect(names).toHaveLength(43);
    expect(names).toContain("oss.inspector.home_feature_prompt_clicked");
    expect(names.filter((name) => !name.startsWith("oss.inspector."))).toEqual(
      [],
    );
  });
});

// ─── Safe URL classification ────────────────────────────────────────────────

describe("getRuntimeUrlType()", () => {
  it("classifies runtime URLs without exposing origins", () => {
    expect(getRuntimeUrlType(undefined)).toBe("missing");
    expect(getRuntimeUrlType("/api/copilotkit")).toBe("relative");
    expect(getRuntimeUrlType("http://localhost:4000")).toBe("localhost");
    expect(getRuntimeUrlType("https://example.com/api")).toBe("remote");
  });
});

// ─── Distinct ID lifecycle ───────────────────────────────────────────────────

describe("distinct ID lifecycle", () => {
  it("persists across calls within the same session", () => {
    const first = getOrCreateTelemetryDistinctId();
    const second = getOrCreateTelemetryDistinctId();
    expect(first).toBe(second);
    expect(
      window.localStorage.getItem("cpk:inspector:telemetry:distinct_id"),
    ).toBe(first);
  });

  it("generates a UUID-v4-shaped value", () => {
    const id = getOrCreateTelemetryDistinctId();
    expect(id).toMatch(
      /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/,
    );
  });

  it("returns a UUID without throwing in SSR (window undefined)", () => {
    vi.stubGlobal("window", undefined);
    expect(() => getOrCreateTelemetryDistinctId()).not.toThrow();
    const id = getOrCreateTelemetryDistinctId();
    expect(id).toMatch(
      /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/,
    );
  });

  it("returns a UUID without throwing when localStorage.getItem throws", () => {
    vi.spyOn(window.localStorage, "getItem").mockImplementation(() => {
      throw new DOMException("QuotaExceededError");
    });
    expect(() => getOrCreateTelemetryDistinctId()).not.toThrow();
    const id = getOrCreateTelemetryDistinctId();
    expect(id).toMatch(/^[0-9a-f]{8}-/);
  });

  it("returns the same UUID across calls when localStorage throws (funnel coherence)", () => {
    vi.spyOn(window.localStorage, "getItem").mockImplementation(() => {
      throw new DOMException("QuotaExceededError");
    });
    vi.spyOn(window.localStorage, "setItem").mockImplementation(() => {
      throw new DOMException("QuotaExceededError");
    });
    const first = getOrCreateTelemetryDistinctId();
    const second = getOrCreateTelemetryDistinctId();
    expect(first).toBe(second);
  });
});

// ─── Announcement read state (host-scoped) ──────────────────────────────────

/**
 * Same host, different port. localStorage is partitioned by origin — which
 * includes the port — so its store starts empty, while the cookie jar is keyed
 * by host and survives. Everything the read state has to do is a consequence
 * of that asymmetry.
 */
// ─── Pulse suppression (per browser tab) ────────────────────────────────────

describe("announcement pulse suppression", () => {
  it("reports nothing pulsed in a fresh tab", () => {
    expect(loadAnnouncementPulsedTimestamp()).toBeNull();
  });

  // Deliberately the timestamp and not a boolean: a boolean would swallow a
  // newly published announcement for the rest of the tab's life.
  it("records which announcement the tab pulsed for", () => {
    window.sessionStorage.setItem(
      "cpk:inspector:pulsed",
      "2026-08-19T10:00:00.000Z",
    );
    expect(loadAnnouncementPulsedTimestamp()).toBe("2026-08-19T10:00:00.000Z");

    window.sessionStorage.setItem(
      "cpk:inspector:pulsed",
      "2026-08-20T10:00:00.000Z",
    );
    expect(loadAnnouncementPulsedTimestamp()).toBe("2026-08-20T10:00:00.000Z");
  });

  it("does not throw when sessionStorage is unavailable", () => {
    vi.stubGlobal("sessionStorage", {
      getItem: () => {
        throw new DOMException("SecurityError");
      },
      setItem: () => {
        throw new DOMException("QuotaExceededError");
      },
    });

    // Losing the suppression costs one extra pulse, never correctness.
    expect(loadAnnouncementPulsedTimestamp()).toBeNull();
  });
});

// ─── One-time reset of the superseded read state ────────────────────────────

describe("legacy announcement read state", () => {
  const LEGACY_KEY = "cpk:inspector:announcements";

  it("is deleted rather than migrated, so every user is re-armed once", () => {
    window.localStorage.setItem(
      LEGACY_KEY,
      JSON.stringify({ timestamp: "2026-08-01T10:00:00.000Z" }),
    );

    clearLegacyAnnouncementReadState();

    expect(window.localStorage.getItem(LEGACY_KEY)).toBeNull();
  });

  it("is safe on every startup, with or without a value to remove", () => {
    expect(() => {
      clearLegacyAnnouncementReadState();
      clearLegacyAnnouncementReadState();
    }).not.toThrow();

    vi.spyOn(window.localStorage, "removeItem").mockImplementation(() => {
      throw new DOMException("SecurityError");
    });
    expect(() => clearLegacyAnnouncementReadState()).not.toThrow();
  });
});

// ─── Persistence error-resilience ───────────────────────────────────────────

describe("persistence error-resilience", () => {
  it("isTelemetryOptedOut returns false (not disabled) when localStorage throws", () => {
    vi.spyOn(window.localStorage, "getItem").mockImplementation(() => {
      throw new DOMException("SecurityError");
    });
    // Must fail to "not opted out" — if it returned true, all users in
    // restricted-storage contexts would have telemetry silently disabled.
    expect(isTelemetryOptedOut()).toBe(false);
  });

  it("setTelemetryOptOut does not throw when localStorage.setItem throws", () => {
    vi.spyOn(window.localStorage, "setItem").mockImplementation(() => {
      throw new DOMException("QuotaExceededError");
    });
    expect(() => setTelemetryOptOut(true)).not.toThrow();
  });

  it("markTelemetryDisclosureShown does not throw when localStorage.setItem throws", () => {
    vi.spyOn(window.localStorage, "setItem").mockImplementation(() => {
      throw new DOMException("QuotaExceededError");
    });
    // Failure means the disclosure fires on every mount instead of once —
    // a UX regression, not a data leak. The important invariant is no throw.
    expect(() => markTelemetryDisclosureShown()).not.toThrow();
  });
});

// ─── maybeShowDisclosure() ───────────────────────────────────────────────────

describe("maybeShowDisclosure()", () => {
  it("logs once and sets the disclosure-shown flag", () => {
    maybeShowDisclosure();
    expect(consoleInfoSpy).toHaveBeenCalledTimes(1);
    const [message] = consoleInfoSpy.mock.calls[0]!;
    expect(message).toContain(TELEMETRY_DOCS_URL);
    expect(hasTelemetryDisclosureBeenShown()).toBe(true);

    maybeShowDisclosure();
    // No second log — flag short-circuits.
    expect(consoleInfoSpy).toHaveBeenCalledTimes(1);
  });

  it("does not log when the user is already opted out", () => {
    setTelemetryOptOut(true);

    maybeShowDisclosure();

    expect(consoleInfoSpy).not.toHaveBeenCalled();
    // The flag stays unset so a future opt-in flips back to "first run"
    // behavior — see the wrapper's design comment.
    expect(hasTelemetryDisclosureBeenShown()).toBe(false);
  });
});

// ─── getTelemetryDistinctIdForUrl() ─────────────────────────────────────────

describe("getTelemetryDistinctIdForUrl()", () => {
  it("returns the persisted distinct-ID when not opted out", () => {
    const id = getTelemetryDistinctIdForUrl();
    expect(id).not.toBeNull();
    expect(id).toMatch(
      /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/,
    );
    // Same ID across calls — ensures URL propagation matches the ID
    // that goes on event sends.
    expect(getTelemetryDistinctIdForUrl()).toBe(id);
  });

  it("returns null when the user is opted out (no cross-domain leak)", () => {
    setTelemetryOptOut(true);
    expect(getTelemetryDistinctIdForUrl()).toBeNull();
  });
});

// ─── Opt-out round-trip ──────────────────────────────────────────────────────

describe("opt-out round-trip", () => {
  it("setTelemetryOptOut(true) → isTelemetryOptedOut() is true", () => {
    expect(isTelemetryOptedOut()).toBe(false);
    setTelemetryOptOut(true);
    expect(isTelemetryOptedOut()).toBe(true);
    setTelemetryOptOut(false);
    expect(isTelemetryOptedOut()).toBe(false);
  });
});
