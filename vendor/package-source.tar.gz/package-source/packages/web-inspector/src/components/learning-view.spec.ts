import { describe, expect, it, vi } from "vitest";
import type {
  InspectorLearningInsight,
  InspectorLearningSnapshotV1,
} from "@copilotkit/shared";
import type { CpkLearningView } from "./learning-view.js";
import { deriveLearningViewState } from "./learning-view.js";

function snapshot(
  overrides: Partial<InspectorLearningSnapshotV1> = {},
): InspectorLearningSnapshotV1 {
  return {
    schemaVersion: 1,
    projectKey: "project-safe-key",
    snapshotVersion: "snapshot-1",
    webAppOrigin: "https://app.copilotkit.ai",
    configuration: { state: "not_configured" },
    pendingThreadCount: 0,
    run: { hasActiveRun: false, hasEverSucceeded: false, latest: null },
    pendingCandidateCount: 0,
    skillsPage: {
      page: 1,
      pageSize: 3,
      total: 0,
      totalPages: 0,
      items: [],
    },
    insightsPage: {
      page: 1,
      pageSize: 4,
      total: 0,
      totalPages: 0,
      items: [],
    },
    links: {
      learning: "https://app.copilotkit.ai/o/acme/checkout/learning",
      candidates: null,
      runs: null,
    },
    ...overrides,
  };
}

const state = (
  current: InspectorLearningSnapshotV1 | null,
  overrides: Partial<Parameters<typeof deriveLearningViewState>[0]> = {},
) =>
  deriveLearningViewState({
    supported: true,
    loading: false,
    error: null,
    snapshot: current,
    setupActive: false,
    ...overrides,
  });

describe("Learning state precedence", () => {
  it("keeps unavailable capability on the product setup path", () => {
    expect(state(null, { supported: false })).toBe("landing");
    expect(state(null, { supported: false, setupActive: true })).toBe("setup");
  });

  it("prioritizes initial load, fatal error, and scope failures", () => {
    expect(state(null, { loading: true })).toBe("loading");
    expect(state(null, { error: "offline" })).toBe("error");
    expect(
      state(snapshot({ configuration: { state: "selection_required" } })),
    ).toBe("selection_required");
    expect(
      state(
        snapshot({
          configuration: { state: "invalid", reason: "instrumentation" },
        }),
      ),
    ).toBe("invalid");
  });

  it("orders results, first run, ready, empty, setup, and landing", () => {
    const configured = {
      state: "configured" as const,
      container: { id: "container-1", name: "Production" },
    };
    expect(state(snapshot({ pendingCandidateCount: 1 }))).toBe("results");
    expect(
      state(
        snapshot({
          configuration: configured,
          run: { hasActiveRun: true, hasEverSucceeded: false, latest: null },
        }),
      ),
    ).toBe("first_run");
    expect(
      state(snapshot({ configuration: configured, pendingThreadCount: 2 })),
    ).toBe("ready");
    expect(
      state(
        snapshot({
          configuration: configured,
          run: { hasActiveRun: false, hasEverSucceeded: true, latest: null },
        }),
      ),
    ).toBe("empty");
    expect(state(snapshot({ configuration: configured }))).toBe("setup");
    expect(state(snapshot(), { setupActive: true })).toBe("setup");
    expect(state(snapshot())).toBe("landing");
  });
});

describe("Learning results hierarchy", () => {
  const resultSnapshot = snapshot({
    configuration: {
      state: "configured",
      container: { id: "container-1", name: "Production" },
    },
    skillsPage: {
      page: 1,
      pageSize: 3,
      total: 1,
      totalPages: 1,
      items: [
        {
          id: "skill-1",
          name: "escalation-summary",
          description: "Summarize the decision before escalating.",
          revision: 2,
          skillMd: "---\nname: escalation-summary\n---\n<script>no()</script>",
          sourceInsight: {
            id: "source-1",
            statement: "Escalations succeed with a decision summary.",
            impact: "Reduces repeat questions.",
            totalThreadCount: 3,
            evidenceTruncated: false,
            evidence: [],
          },
        },
      ],
    },
    insightsPage: {
      page: 1,
      pageSize: 4,
      total: 1,
      totalPages: 1,
      items: [
        {
          id: "insight-1",
          statement: "Customers confirm ownership faster with a named owner.",
          impact: "Shortens handoffs.",
          totalThreadCount: 2,
          evidenceTruncated: false,
          evidence: [],
        },
      ],
    },
  });

  async function renderResults() {
    const view = document.createElement("cpk-learning-view") as CpkLearningView;
    view.supported = true;
    view.snapshot = resultSnapshot;
    document.body.append(view);
    await view.updateComplete;
    return view;
  }

  it("keeps Skills first and renders the first SKILL.md in a native disclosure", async () => {
    const view = await renderResults();
    const headings = [...view.shadowRoot!.querySelectorAll("h2")].map(
      (heading) => heading.textContent?.trim(),
    );
    expect(headings).toEqual(["Skills in registry", "More Insights"]);
    const disclosure = view.shadowRoot!.querySelector("details");
    expect(disclosure?.open).toBe(false);
    expect(disclosure?.querySelector("summary")?.textContent).toContain(
      "View SKILL.md",
    );
    expect(disclosure?.querySelector("pre")?.textContent).toContain(
      "<script>no()</script>",
    );
    expect(disclosure?.querySelector("script")).toBeNull();
    view.remove();
  });

  it("keeps the empty-result Intelligence link quiet and safe", async () => {
    const view = document.createElement("cpk-learning-view") as CpkLearningView;
    view.supported = true;
    view.snapshot = snapshot({
      configuration: {
        state: "configured",
        container: { id: "container-1", name: "Production" },
      },
      run: {
        hasActiveRun: false,
        hasEverSucceeded: true,
        latest: null,
      },
      links: {
        learning:
          "https://app.copilotkit.ai/o/acme/checkout/learning/container-1",
        candidates: null,
        runs: null,
      },
    });
    document.body.append(view);
    await view.updateComplete;

    const link =
      view.shadowRoot!.querySelector<HTMLAnchorElement>("a.quiet-link");
    expect(link?.textContent?.trim()).toBe("Open in web app ↗");
    expect(link?.href).toBe(
      "https://app.copilotkit.ai/o/acme/checkout/learning/container-1",
    );
    expect(link?.target).toBe("_blank");
    expect(link?.rel.split(/\s+/).sort()).toEqual(["noopener", "noreferrer"]);
    view.remove();
  });

  it("opens Intelligence from results even without new Threads or pending candidates", async () => {
    const view = await renderResults();
    const link =
      view.shadowRoot!.querySelector<HTMLAnchorElement>(".pane-actions a");
    expect(link?.textContent?.trim()).toBe("Open Intelligence ↗");
    expect(link?.href).toBe("https://app.copilotkit.ai/");
    view.remove();
  });

  it("labels evidence, shows impact and Thread count, and emits on detail open", async () => {
    const view = await renderResults();
    let opened = 0;
    view.addEventListener("learning-evidence-opened", () => {
      opened += 1;
    });
    const labels = [
      ...view.shadowRoot!.querySelectorAll(".list-header span"),
    ].map((label) => label.textContent);
    expect(labels).toEqual(["Pattern", "Evidence"]);
    const row =
      view.shadowRoot!.querySelector<HTMLButtonElement>(".insight-row");
    expect(row?.textContent).toContain("Shortens handoffs.");
    expect(row?.textContent).toMatch(/2\s*Threads/);
    row?.click();
    await view.updateComplete;
    expect(opened).toBe(1);
    expect(view.shadowRoot!.textContent).toContain(
      "Evidence is no longer available",
    );
    view.remove();
  });

  it("keeps unavailable evidence inert and preserves the unnamed accessible Thread fallback", async () => {
    const view = await renderResults();
    view.snapshot = snapshot({
      configuration: {
        state: "configured",
        container: { id: "container-1", name: "Production" },
      },
      insightsPage: {
        page: 1,
        pageSize: 4,
        total: 1,
        totalPages: 1,
        items: [
          {
            id: "insight-private",
            statement: "Evidence availability is checked before navigation.",
            impact: "Deleted evidence stays private.",
            totalThreadCount: 2,
            evidenceTruncated: false,
            evidence: [
              { status: "unavailable" },
              {
                status: "available",
                threadId: "thread-accessible",
                threadName: null,
                messageIds: ["message-accessible"],
                updatedAt: "2026-03-10T09:15:00.000Z",
              },
            ],
          },
        ],
      },
    });
    await view.updateComplete;
    view.shadowRoot?.querySelector<HTMLButtonElement>(".insight-row")?.click();
    await view.updateComplete;

    const unavailable = view.shadowRoot!.querySelector(".evidence-unavailable");
    expect(unavailable?.textContent?.replace(/\s+/g, " ").trim()).toBe(
      "1 Thread is no longer available",
    );
    expect(unavailable?.querySelector("button, a")).toBeNull();
    const accessible =
      view.shadowRoot!.querySelector<HTMLButtonElement>(".evidence-link");
    expect(accessible?.textContent).toContain("Thread thread-a");
    expect(view.shadowRoot!.textContent).not.toContain("message-accessible");
    view.remove();
  });

  it("counts and links Trajectory evidence when an Insight cites no Thread", async () => {
    const view = await renderResults();
    view.snapshot = snapshot({
      configuration: {
        state: "configured",
        container: { id: "container-1", name: "Production" },
      },
      insightsPage: {
        page: 1,
        pageSize: 4,
        total: 1,
        totalPages: 1,
        items: [
          {
            id: "insight-trajectory",
            statement: "Users switch the theme before they start.",
            impact: "Default to the dark theme.",
            totalThreadCount: 0,
            evidenceTruncated: false,
            evidence: [],
            totalTrajectoryCount: 2,
            trajectoryEvidence: [
              {
                status: "available",
                trajectoryId: "0190a3b4-0000-7000-8000-000000000001",
                eventCount: 2,
                url: "https://app.copilotkit.ai/o/acme/checkout/trajectories/0190a3b4-0000-7000-8000-000000000001?event=901",
              },
              { status: "unavailable" },
            ],
          },
        ],
      },
    });
    const opened: unknown[] = [];
    view.addEventListener("learning-web-link", (event) => {
      opened.push((event as CustomEvent).detail);
    });
    await view.updateComplete;

    const row =
      view.shadowRoot!.querySelector<HTMLButtonElement>(".insight-row");
    expect(row?.querySelector(".evidence-count")?.textContent).toMatch(
      /^\s*2\s*Trajectories\s*$/,
    );
    row?.click();
    await view.updateComplete;
    const link =
      view.shadowRoot!.querySelector<HTMLAnchorElement>("a.evidence-link");
    expect(link?.href).toBe(
      "https://app.copilotkit.ai/o/acme/checkout/trajectories/0190a3b4-0000-7000-8000-000000000001?event=901",
    );
    expect(link?.target).toBe("_blank");
    expect(link?.rel.split(/\s+/).sort()).toEqual(["noopener", "noreferrer"]);
    const createdAt = new Intl.DateTimeFormat(undefined, {
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "2-digit",
    }).format(new Date(0x0190a3b40000));
    expect(link?.textContent).toContain(`Trajectory · ${createdAt}`);
    expect(link?.querySelector(".evidence-id")?.textContent).toBe("00000001");
    expect(link?.title).toBe("0190a3b4-0000-7000-8000-000000000001");
    expect(link?.textContent).toContain("2 cited events");
    expect(link?.textContent).toContain("Open Trajectory");
    expect(
      view.shadowRoot!.querySelectorAll(".evidence-unavailable"),
    ).toHaveLength(1);
    link?.addEventListener("click", (event) => event.preventDefault());
    link?.click();
    expect(opened).toEqual([{ category: "trajectory" }]);
    view.remove();
  });

  it("counts cited Trajectories from the evidence when the total is absent", async () => {
    const view = await renderResults();
    view.snapshot = snapshot({
      ...resultSnapshot,
      insightsPage: {
        ...resultSnapshot.insightsPage,
        items: [
          {
            id: "insight-evidence-only",
            statement: "Shoppers open the size guide before they pick a size.",
            impact: "Link the size guide next to the size picker.",
            totalThreadCount: 0,
            evidenceTruncated: false,
            evidence: [],
            trajectoryEvidence: [{ status: "unavailable" }],
          },
        ],
      },
    });
    await view.updateComplete;

    expect(
      view.shadowRoot!.querySelector(".insight-row .evidence-count")
        ?.textContent,
    ).toMatch(/^\s*1\s*Trajectory\s*$/);
    view.remove();
  });

  it("shows Thread and Trajectory counts together for mixed evidence", async () => {
    const view = await renderResults();
    const mixed = {
      id: "insight-mixed",
      statement: "Users ask before they switch the theme.",
      impact: "Offer the theme in chat.",
      totalThreadCount: 2,
      evidenceTruncated: false,
      evidence: [],
      totalTrajectoryCount: 1,
      trajectoryEvidence: [
        {
          status: "available" as const,
          trajectoryId: "trajectory-1",
          eventCount: 1,
          url: "https://app.copilotkit.ai/o/acme/checkout/trajectories/trajectory-1",
        },
      ],
    };
    view.snapshot = snapshot({
      ...resultSnapshot,
      skillsPage: {
        ...resultSnapshot.skillsPage,
        items: [
          {
            ...resultSnapshot.skillsPage.items[0]!,
            sourceInsight: { ...mixed, id: "source-mixed" },
          },
        ],
      },
      insightsPage: { ...resultSnapshot.insightsPage, items: [mixed] },
    });
    await view.updateComplete;

    expect(
      view.shadowRoot!.querySelector(".insight-row .evidence-count")
        ?.textContent,
    ).toMatch(/2\s*Threads\s*·\s*1\s*Trajectory/);
    expect(
      view.shadowRoot!.querySelector(".skill-lineage small")?.textContent,
    ).toMatch(/2\s*Threads\s*·\s*1\s*Trajectory/);
    view.remove();
  });

  describe("evidence panel", () => {
    const trajectory = (index: number) => {
      const trajectoryId = `0190a3b4-0000-7000-8000-${String(index).padStart(12, "0")}`;
      return {
        status: "available" as const,
        trajectoryId,
        eventCount: 1,
        url: `https://app.copilotkit.ai/o/acme/checkout/trajectories/${trajectoryId}`,
      };
    };
    const thread = (index: number) => ({
      status: "available" as const,
      threadId: `thread-${index}`,
      threadName: `Thread name ${index}`,
      messageIds: [`message-${index}`],
      updatedAt: "2026-03-10T09:15:00.000Z",
    });

    async function openEvidence(
      insight: Partial<InspectorLearningInsight>,
    ): Promise<CpkLearningView> {
      const view = await renderResults();
      view.snapshot = snapshot({
        ...resultSnapshot,
        insightsPage: {
          ...resultSnapshot.insightsPage,
          items: [
            {
              id: "insight-panel",
              statement: "Shoppers compare plans before they upgrade.",
              impact: "Show the plan table first.",
              totalThreadCount: 0,
              evidenceTruncated: false,
              evidence: [],
              ...insight,
            },
          ],
        },
      });
      await view.updateComplete;
      view
        .shadowRoot!.querySelector<HTMLButtonElement>(".insight-row")!
        .click();
      await view.updateComplete;
      return view;
    }

    const text = (element: Element | null | undefined) =>
      element?.textContent?.replace(/\s+/g, " ").trim();

    it("shows the first rows of each kind and toggles the rest", async () => {
      const view = await openEvidence({
        totalTrajectoryCount: 14,
        trajectoryEvidence: Array.from({ length: 14 }, (_, index) =>
          trajectory(index + 1),
        ),
      });
      const rows = () =>
        view.shadowRoot!.querySelectorAll("a.evidence-link").length;
      expect(rows()).toBe(10);
      const more =
        view.shadowRoot!.querySelector<HTMLButtonElement>(".evidence-more");
      expect(text(more)).toBe("Show 4 more Trajectories");
      expect(more?.getAttribute("aria-expanded")).toBe("false");

      more!.click();
      await view.updateComplete;
      expect(rows()).toBe(14);
      expect(text(view.shadowRoot!.querySelector(".evidence-more"))).toBe(
        "Show fewer Trajectories",
      );
      view.remove();
    });

    it("collapses unavailable evidence into one line per kind", async () => {
      const view = await openEvidence({
        totalThreadCount: 2,
        evidence: [thread(1), { status: "unavailable" }],
        totalTrajectoryCount: 3,
        trajectoryEvidence: [
          trajectory(1),
          { status: "unavailable" },
          { status: "unavailable" },
        ],
      });
      expect(
        [...view.shadowRoot!.querySelectorAll(".evidence-unavailable")].map(
          text,
        ),
      ).toEqual([
        "1 Thread is no longer available",
        "2 Trajectories are no longer available",
      ]);
      expect(
        [...view.shadowRoot!.querySelectorAll(".evidence-group-heading")].map(
          text,
        ),
      ).toEqual(["Threads", "Trajectories"]);
      view.remove();
    });

    it("omits kind headings when only one kind is cited", async () => {
      const view = await openEvidence({
        totalThreadCount: 1,
        evidence: [thread(1)],
      });
      expect(
        view.shadowRoot!.querySelector(".evidence-group-heading"),
      ).toBeNull();
      view.remove();
    });

    it("states how much of a shortened response is listed", async () => {
      const view = await openEvidence({
        evidenceTruncated: true,
        totalThreadCount: 1,
        evidence: [thread(1)],
        totalTrajectoryCount: 412,
        trajectoryEvidence: [trajectory(1), trajectory(2)],
      });
      expect(text(view.shadowRoot!.querySelector(".evidence-coverage"))).toBe(
        "Showing 2 of 412 Trajectories",
      );
      expect(view.shadowRoot!.textContent).not.toContain(
        "Evidence response shortened",
      );
      view.remove();
    });

    it("keeps the shortened note when every source is listed", async () => {
      const view = await openEvidence({
        evidenceTruncated: true,
        totalThreadCount: 1,
        evidence: [thread(1)],
      });
      expect(view.shadowRoot!.querySelector(".evidence-coverage")).toBeNull();
      expect(view.shadowRoot!.textContent).toContain(
        "Evidence response shortened",
      );
      view.remove();
    });

    it("falls back to the id tail for Trajectory ids that are not UUIDv7", async () => {
      const view = await openEvidence({
        totalTrajectoryCount: 1,
        trajectoryEvidence: [
          {
            ...trajectory(1),
            trajectoryId: "0190a3b4-0000-4000-8000-0000000000aa",
          },
        ],
      });
      const link = view.shadowRoot!.querySelector("a.evidence-link");
      expect(text(link)).toContain("Trajectory 000000aa · 1 cited event");
      expect(link?.querySelector(".evidence-id")).toBeNull();
      view.remove();
    });
  });
});

describe("Learning setup progress", () => {
  async function renderProgress(
    current: InspectorLearningSnapshotV1,
    setupActive = false,
  ) {
    const view = document.createElement("cpk-learning-view") as CpkLearningView;
    view.supported = true;
    view.snapshot = current;
    view.setupActive = setupActive;
    document.body.append(view);
    await view.updateComplete;
    return view;
  }

  it.each([
    {
      overrides: { configuration: { state: "selection_required" as const } },
      selectors: [["a.primary", "learning"]],
    },
    {
      overrides: { pendingThreadCount: 3 },
      selectors: [["a.setup-cta", "runs"]],
    },
    {
      overrides: {
        run: { hasActiveRun: true, hasEverSucceeded: false, latest: null },
      },
      selectors: [["a.setup-cta", "runs"]],
    },
    {
      overrides: { pendingCandidateCount: 2, pendingThreadCount: 3 },
      selectors: [
        [".pane-actions a", "home"],
        ["a.review-link", "candidates"],
        ["a.results-cta", "runs"],
      ],
    },
  ])(
    "preserves each scoped action and the general app link: %j",
    async ({ overrides, selectors }) => {
      const origin = "https://intelligence.customer.example";
      const learning = `${origin}/o/acme/project/learning/container-1`;
      const destinations: Record<string, string> = {
        home: `${origin}/`,
        learning,
        candidates: `${learning}/skills`,
        runs: `${learning}/analysis-results`,
      };
      const view = await renderProgress(
        snapshot({
          configuration: {
            state: "configured",
            container: { id: "container-1", name: "Production" },
          },
          webAppOrigin: origin,
          links: {
            learning,
            candidates: destinations.candidates!,
            runs: destinations.runs!,
          },
          ...overrides,
        }),
      );
      const opened = vi.fn();
      view.addEventListener("learning-web-link", opened);
      expect(view.shadowRoot!.querySelectorAll("a")).toHaveLength(
        selectors.length,
      );
      for (const [selector, category] of selectors) {
        const link = view.shadowRoot!.querySelector<HTMLAnchorElement>(
          selector!,
        );
        expect(link?.href).toBe(destinations[category!]);
        expect(link?.target).toBe("_blank");
        expect(link?.rel.split(/\s+/).sort()).toEqual([
          "noopener",
          "noreferrer",
        ]);
        link!.click();
        expect(opened.mock.calls.at(-1)?.[0].detail).toEqual({
          category: category === "home" ? "learning" : category,
        });
      }
      view.remove();
    },
  );

  it("shows all three setup steps and keeps analysis disabled while waiting", async () => {
    const view = await renderProgress(snapshot(), true);
    expect(view.shadowRoot!.textContent).toContain("1 of 3 steps");
    expect(view.shadowRoot!.textContent).toContain(
      "Waiting for Automatic Learning setup",
    );
    expect(view.shadowRoot!.textContent).toContain("Copy the setup prompt");
    expect(view.shadowRoot!.textContent).toContain("Set up Automatic Learning");
    expect(view.shadowRoot!.textContent).toContain(
      "Nice work. You’ve completed the first step.",
    );
    expect(view.shadowRoot!.querySelectorAll(".step")).toHaveLength(3);
    const [promptStep, setupStep] = [
      ...view.shadowRoot!.querySelectorAll<HTMLElement>(".step"),
    ];
    if (!promptStep || !setupStep) {
      throw new Error("Expected the first two Learning setup steps.");
    }
    expect(promptStep.classList.contains("complete")).toBe(true);
    expect(promptStep.querySelector(".step-number")?.textContent).toBe("✓");
    expect(setupStep.classList.contains("current")).toBe(true);
    expect(
      view.shadowRoot!.querySelector<HTMLButtonElement>(".copy-again")
        ?.textContent,
    ).toContain("Copy prompt again");
    expect(
      view.shadowRoot!.querySelector<HTMLButtonElement>(".pane-actions button")
        ?.textContent,
    ).toContain("Go back");
    expect(
      view.shadowRoot!.querySelector<HTMLButtonElement>("button[disabled]")
        ?.textContent,
    ).toContain("Analyze Threads");
    view.remove();
  });

  it("emits copy and back actions from setup progress", async () => {
    const view = await renderProgress(snapshot(), true);
    const copy = vi.fn();
    const goBack = vi.fn();
    view.addEventListener("learning-recopy-setup", copy);
    view.addEventListener("learning-go-back", goBack);

    view.shadowRoot!.querySelector<HTMLButtonElement>(".copy-again")?.click();
    view
      .shadowRoot!.querySelector<HTMLButtonElement>(".pane-actions button")
      ?.click();

    expect(copy).toHaveBeenCalledOnce();
    expect(goBack).toHaveBeenCalledOnce();
    view.remove();
  });

  it("confirms when the setup prompt is copied again", async () => {
    const view = await renderProgress(snapshot(), true);
    view.recopyState = "copied";
    await view.updateComplete;

    expect(
      view.shadowRoot!.querySelector<HTMLButtonElement>(".copy-again")
        ?.textContent,
    ).toContain("Copied!");
    view.remove();
  });

  it("marks Thread capture complete before handing a ready run to the web app", async () => {
    const view = await renderProgress(
      snapshot({
        configuration: {
          state: "configured",
          container: { id: "container-1", name: "Production" },
        },
        pendingThreadCount: 3,
        links: {
          learning: "https://app.copilotkit.ai/o/acme/checkout/learning",
          candidates: null,
          runs: "https://app.copilotkit.ai/o/acme/checkout/learning/container-1/analysis-results",
        },
      }),
    );
    expect(view.shadowRoot!.textContent).toContain("2 of 3 steps");
    expect(view.shadowRoot!.textContent).toContain("Threads ready to analyze");
    expect(view.shadowRoot!.textContent).toMatch(/3\s*New Threads/);
    expect(view.shadowRoot!.querySelector("a")?.textContent).toContain(
      "Open in web app",
    );
    view.remove();
  });

  it("renders setup failures as an alert at step two", async () => {
    const view = await renderProgress(
      snapshot({
        configuration: { state: "invalid", reason: "instrumentation" },
      }),
    );
    expect(view.shadowRoot!.textContent).toContain("Needs attention");
    expect(
      view.shadowRoot!.querySelector('[role="alert"]')?.textContent,
    ).toContain("Inspector did not find the Learning Space");
    view.remove();
  });

  it("keeps every retained snapshot state retryable after a refresh error", async () => {
    const configured = {
      state: "configured" as const,
      container: { id: "container-1", name: "Production" },
    };
    const retainedStates = [
      ["setup", snapshot({ configuration: configured })],
      [
        "first_run",
        snapshot({
          configuration: configured,
          run: { hasActiveRun: true, hasEverSucceeded: false, latest: null },
        }),
      ],
      ["ready", snapshot({ configuration: configured, pendingThreadCount: 1 })],
      [
        "empty",
        snapshot({
          configuration: configured,
          run: { hasActiveRun: false, hasEverSucceeded: true, latest: null },
        }),
      ],
      [
        "invalid",
        snapshot({
          configuration: { state: "invalid", reason: "instrumentation" },
        }),
      ],
      [
        "selection_required",
        snapshot({ configuration: { state: "selection_required" } }),
      ],
    ] as const;

    for (const [expectedState, current] of retainedStates) {
      const view = await renderProgress(current);
      view.error = "Could not refresh Learning";
      await view.updateComplete;
      expect(
        view.shadowRoot!.querySelector("main")?.dataset.learningState,
      ).toBe(expectedState);
      expect(view.shadowRoot!.querySelectorAll(".retry-strip")).toHaveLength(1);
      view.remove();
    }
  });

  it("keeps the setup prompt modal keyboard-accessible", async () => {
    const view = await renderProgress(
      snapshot({
        configuration: { state: "invalid", reason: "instrumentation" },
      }),
    );
    view.setupPrompt = "Set up Learning";
    await view.updateComplete;

    const trigger =
      view.shadowRoot!.querySelector<HTMLButtonElement>(".prompt-link");
    if (!trigger) throw new Error("Expected the setup prompt trigger.");
    trigger.focus();
    trigger.click();
    await view.updateComplete;

    const dialog = view.shadowRoot!.querySelector<HTMLElement>(".dialog");
    const close =
      view.shadowRoot!.querySelector<HTMLButtonElement>(".dialog-close");
    const copy = view.shadowRoot!.querySelector<HTMLButtonElement>(
      ".dialog footer .primary",
    );
    if (!dialog || !close || !copy) {
      throw new Error("Expected the complete setup prompt dialog.");
    }
    expect(view.shadowRoot!.activeElement).toBe(close);

    copy.focus();
    copy.dispatchEvent(
      new KeyboardEvent("keydown", { bubbles: true, key: "Tab" }),
    );
    expect(view.shadowRoot!.activeElement).toBe(close);

    dialog.dispatchEvent(
      new KeyboardEvent("keydown", { bubbles: true, key: "Escape" }),
    );
    await view.updateComplete;
    expect(view.shadowRoot!.querySelector(".dialog")).toBeNull();
    expect(view.shadowRoot!.activeElement).toBe(trigger);
    view.remove();
  });
});
